package javaJDBC;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CrudEx {
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
		// 5 + 1 steps
		//step-1 loading the driver class--->oracledriver
		
		Class.forName("oracle.jdbc.driver.OracleDriver");
		
		//step-2 create connection

		Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@10.219.34.3:1521:orcl","trg406","training406");
		
		//step-3 create statement
		
		Statement stmt=conn.createStatement();
		
		//step-4 execute query
		
		//boolean val=stmt.execute("create table emp11(eid number,ename varchar2(20))");
		int result1=stmt.executeUpdate("insert into emp11 values(111,'kaviya')");
		int result2=stmt.executeUpdate("insert into emp11 values(112,'pradi')");
		int result=stmt.executeUpdate("delete from emp11 where eid=123");
		//System.out.println("table created"+val);
		System.out.println("table created"+result);
		//ddl--execute()---boolean
		//dml--executeUpdate()---int
		//drl--excuteQuery---resultset
		// step-5 close the connection
		
		conn.close();
	}
	}
