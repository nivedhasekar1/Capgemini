
public class sample2 {

}
