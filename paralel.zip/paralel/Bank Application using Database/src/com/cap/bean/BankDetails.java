package com.cap.bean;

public class BankDetails
{
    private String custName;
    private long  custMobNum;
    private String accType;
    private long accBal;
    private String custBranch;
    private long accNum;
    private long depAcc;
    
    //setter and getters
    public long getDepAcc() {
        return depAcc;
    }
    public void setDepAcc(long depAcc) {
        this.depAcc = depAcc;
    }
    public long getAccNum() {
        return accNum;
    }
    public void setAccNum(long accNum) {
        this.accNum = accNum;
    }
    public String getCustName() {
        return custName;
    }
    public void setCustName(String custName) {
        this.custName = custName;
    }
    public long getCustMobNum() {
        return custMobNum;
    }
    public void setCustMobNum(long custMobNum) {
        this.custMobNum = custMobNum;
    }
    public String getAccType() {
        return accType;
    }
    public void setAccType(String accType) {
        this.accType = accType;
    }
    public long getAccBal() {
        return accBal;
    }
    public void setAccBal(long accBal) {
        this.accBal = accBal;
    }
    public String getCustBranch() {
        return custBranch;
    }
    public void setCustBranch(String custBranch) {
        this.custBranch = custBranch;
    }
    @Override
    public String toString() {
        return "BankDetails [custName=" + custName + ", custMobNum=" + custMobNum + ", accType=" + accType + ", accBal="
                + accBal + ", custBranch=" + custBranch + ", accNum=" + accNum + ",]";
    }
    
    
}