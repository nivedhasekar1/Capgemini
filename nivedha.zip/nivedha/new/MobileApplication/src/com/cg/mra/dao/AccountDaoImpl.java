package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;
import com.cp.mra.exception.AccountNotFoundException;

public class AccountDaoImpl implements AccountDao {
	
	
	    Map<String, Account> accountEntry;

	 

	    public AccountDaoImpl () {
	        accountEntry = new HashMap<>();
	        accountEntry.put("9010210131", new Account("Prepaid", "vaishali", 200));
	        accountEntry.put("9823920123", new Account("Prepaid", "megha", 453));
	        accountEntry.put("9932012345", new Account("Prepaid", "vikash", 631));
	        accountEntry.put("9010210131", new Account("Prepaid", "anju", 521));
	        accountEntry.put("9010210131", new Account("Prepaid", "tushar", 632));

	 

	    }

	 

	    @Override
	    public Account getAccountDetails(String mobileNo) {
	       // Account account = accountEntry.get(mobileNo);
	    	Account account = accountEntry.get(mobileNo);
	        if (account == null) {
	            throw new AccountNotFoundException(" Given Mobile number does not Exists");
	        }

	 

	        return account;
	    }

	 

	    @Override
	    public Account rechargeAccount(String mobileNo1, double rechargeAmount) {
	        Account account = accountEntry.get(mobileNo1);
	        if (account == null) {
	            throw new AccountNotFoundException(" Given Mobile Number doesnot exist");
	        }
	        double a = account.getAccountBalance();
	        a += rechargeAmount;
	        account.setAccountBalance(a);
	        return account;
	    }

	 

	}