package com.cons;

interface Sap {
void a2();
void a3();
}
public class T12 implements Sap{
	public void a1(){
		System.out.println("test class");
	}
	public static void main(String[] args) {
		T12 a=new T12();
		a.a1();
		a.a2();
		a.a3();
		
}
	@Override
	public
	void a3(){
		//TODO Auto-generated method stub
		System.out.println("welcome");
	}
	@Override
	public void a2() {
		// TODO Auto-generated method stub
		
	}
} 