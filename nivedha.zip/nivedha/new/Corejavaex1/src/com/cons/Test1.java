package com.cons;
class Sam1{
	void add(){
		System.out.println("add");
	}
	 void add1(){
		System.out.println("add1");
	}
}
public class Test1 extends Sam1 {
	void add1()
	{
		System.out.println("method");
	}
	public static void main(String[] args) {
		Test1 t=new Test1();
		t.add();
		t.add1();
	}

}
