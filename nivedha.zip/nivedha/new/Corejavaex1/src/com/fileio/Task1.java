package com.fileio;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

 

    class Emp7
    {
        int eid;
        String ename;
        int esalary;
        @Override
        public String toString() {
            return "Emp7 [eid=" + eid + ", ename=" + ename + ", esalary=" + esalary + "]";
        }
        Emp7(String name,int salary,int id)
        {
            this.eid=id;
            this.ename=name;
            this.esalary=salary;
            
        }
    }
public class Task1 
{
    public static void main(String[] args) 
    {
         
           
            Emp7 e1=new Emp7("pradi",15000,101);
            Emp7 e2=new Emp7("kavya",10000,102);
            Emp7 e3=new Emp7("mercy",10000,103);
            Emp7 e4=new Emp7("nancy",10000,104);
            
            HashMap<String,Emp7> hm=new HashMap<String,Emp7>();
            
            hm.put("6585598431", e1);
            hm.put("9876543210", e2);
            hm.put("5570548743", e3);
            hm.put("8597919876", e4);
           
            System.out.println(hm);
            
          Set set=hm.entrySet();
            Iterator itr=set.iterator();
            while(itr.hasNext())
            {
                Entry entry=(Entry) itr.next();
                System.out.println(entry.getKey());
                System.out.println(entry.getValue());
            }
            Scanner sc= new Scanner(System.in);
            System.out.println("Enter mobile number: ");
            String mob=sc.next();
            Emp7 e=(Emp7) hm.get(mob);
            System.out.println(e.esalary);
            System.out.println("your old sal:"+e.esalary);
            System.out.println("your udated sal:"+(e.esalary+23000));
           //System.out.println(hm.containsKey(mob));
}
}
