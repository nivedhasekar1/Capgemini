package com.fileio;

import java.util.TreeSet;

public class Com {
public static void main(String[] args) {
	
	System.out.println("a".compareTo("q"));
	System.out.println("w".compareTo("w"));
	System.out.println("b".compareTo("a"));
	System.out.println("b".compareTo(null));//--RE  nullpointer exception
	 
}
}

//--return -ve if obj1 has to come before obj2
//--return +ve if obj1 has to come after obj2
//--return 0 both are equal
