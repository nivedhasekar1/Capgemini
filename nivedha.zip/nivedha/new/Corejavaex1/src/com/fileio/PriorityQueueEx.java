package com.fileio;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueEx {
public static void main(String[] args) {
	PriorityQueue q=new PriorityQueue();
	q.add("a");
	q.add("b");
	q.add("c");
	q.add("d");
	System.out.println(q);
	System.out.println(q.element());
	System.out.println(q.peek());
	System.out.println("head:"+q.remove());
	System.out.println(q);
	System.out.println("iterating the queue elements:");
	
	Iterator itr=q.iterator();
	
	while(itr.hasNext()){
		System.out.println(itr.next());
	}
}
}
