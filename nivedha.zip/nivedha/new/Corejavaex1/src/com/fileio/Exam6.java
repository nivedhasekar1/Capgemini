package com.fileio;

import java.util.ArrayList;

class Emp2 {
		String name;
		int eid;
		int esal;
		public Emp2(String name,int eid,int esal){
			super();
			this.name=name;
			this.eid=eid;
			this.esal=esal;
		}
@Override
public String toString() {
	return name + "--" +eid+"--"+esal;
	//return "Emp2 [eid=" +eid+",name=" + name+",esal="+esal];
}}
		public  class Exam6 {

			

			public static void main(String[] args) {
				Emp2 e1=new Emp2("pradi",130,15000);
				Emp2 e2=new Emp2("merlin",150,15000);
				Emp2 e3=new Emp2("kaviya",100,15000);
				Emp2 e4=new Emp2("mercy",170,15000);
	ArrayList a1=new ArrayList();
	a1.add(e1);
	a1.add(e2);
	a1.add(e3);
	a1.add(e4);
	System.out.println(a1);
	
			}}
