package com.fileio;

import java.util.TreeMap;

public class TreeMa {
public static void main(String[] args) {
	TreeMap<Integer,String> ht=new TreeMap<Integer,String>();//key-integer ,value-string
	TreeMap h=new TreeMap();
	h.put(1, "hi");
	h.put(2, "hello");
	h.put(3, "hi");
	h.put(4, "hello");
	System.out.println(h);
	ht.put(1, "hi");
	ht.put(2, "hello");
	ht.put(3, "hi");
	System.out.println(ht);
}
}
