package com.fileio;

import java.util.Comparator;
import java.util.TreeSet;

class Emp1 implements Comparable{
	String name;
	int eid;
	Emp1(String name,int eid){
		this.name=name;
		this.eid=eid;
	}
	public String toString(){
		return name + "--" +eid;
	}
	@Override
	public int compareTo(Object obj1) {
		int eid1=this.eid;
		Emp1 e=(Emp1) obj1;
		int eid2=e.eid;
		if(eid1<eid2)
			return +1;
		else if(eid>eid2)
			return -1;
		else
		// TODO Auto-generated method stub
		return 0;
	}

}
class MyCom implements Comparator{

	@Override
	public int compare(Object obj1, Object obj2) {
		Emp1 e1=(Emp1) obj1;
		Emp1 e2=(Emp1) obj2;
		String s1=e1.name;
		String s2=e2.name;
		// TODO Auto-generated method stub
		return -s1.compareTo(s2);
	}
	
}
public class Empcom {
	public static void main(String[] args) {
		Emp1 e1=new Emp1("p",130);
		Emp1 e2=new Emp1("m",150);
		Emp1 e3=new Emp1("k",100);
		Emp1 e4=new Emp1("e",170);
		TreeSet t=new TreeSet();
		t.add(e1);
		t.add(e2);
		t.add(e3);
		t.add(e4);
		System.out.println(t);
		TreeSet t1=new TreeSet(new MyCom());
		t1.add(e1);
		t1.add(e2);
		t1.add(e3);
		t1.add(e4);
		System.out.println(t1);
	}

}
