package com.fileio;
import java.io.*;
public class Exam5 {
	public static void main(String[] args) throws Exception  {
		FileInputStream f= new FileInputStream("capg.txt");
		ObjectInputStream o=new ObjectInputStream(f);
		Emp s=(Emp)o.readObject();
		System.out.println(s.getName());
		System.out.println(s.getEmpid());
		System.out.println(s.getSal());
	}
}
