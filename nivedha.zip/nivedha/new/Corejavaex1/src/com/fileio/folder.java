package com.fileio;
import java.io.*;
public class folder {
public static void main(String[] args) throws IOException {
	File f=new File("folder/folder1/myfile.txt");
			f.getParentFile().mkdirs();//more than one folder
			//f.getParentFile().mkdir(); for only one folder
			f.createNewFile();
			System.out.println("done");
			System.out.println(f.getPath());
	System.out.println(f.getAbsolutePath());
	
}
}
