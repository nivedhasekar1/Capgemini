package com.flow;

/*public class flow {
	public static void main(String[] args) {
		int x=10;
		if(x==20)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
	
	}

}
}

output:
	hi*/

//ex2

/*public class flow {
	public static void main(String[] args) {
		int x=10;
		if(x=20)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
	
	}

}
}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		Type mismatch: cannot convert from int to boolean

		at com.flow.flow.main(flow.java:25)*/


//ex3
/*public class flow {
	public static void main(String[] args) {
		int x=0;
		if(x)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
	
	}

}
}

output:
Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
	Type mismatch: cannot convert from int to boolean

	at com.flow.flow.main(flow.java:53)*/

//ex4

/*public class flow {
	public static void main(String[] args) {
		boolean x=true;
		if(x=false)
		{
			System.out.println("hello");
		}
		else
		{
			System.out.println("hi");
	
	}

}
}

output:
	hi*/

//ex5
/*public class flow
{
public static void main(String[] args) {
	boolean x=false;
	if(x=false)
	{
		System.out.println("hello");
	}
	else
	{
		System.out.println("hi");

}

}
}

output:
	hi*/

//ex6
/*public class flow
{
public static void main(String[] args) {
	if(true)
	{
		System.out.println("hello");
	}
}
}

output:
	hello*/

//ex6
/*public class flow
{
public static void main(String[] args) {
	if(true);
}
}

output:
	
	
	*/

//ex6
/*public class flow
{
public static void main(String[] args) {
	if(true)
 int x=10;	
	}

}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
		Syntax error, insert ". class" to complete Expression
		Syntax error, insert "AssignmentOperator Expression" to complete Assignment
		Syntax error, insert ";" to complete Statement
		The left-hand side of an assignment must be a variable
		x cannot be resolved to a variable

		at com.flow.flow.main(flow.java:144)*/

//ex7
/*public class flow
{
public static void main(String[] args) {
	if(true)
	{
		int x=10;
	}
	}
}

output:
	
	
	
	*/

//ex8 switch
/*public class flow
{
public static void main(String[] args) {
	int x=10;
	switch(x)
	{
	
	}
	}
}
		
output:
	
	
	*/

//ex9
/*public class flow
{
public static void main(String[] args) {
	int x=10;
	switch(x)
	{
	System.out.println("hello");
	}
	}
}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		Syntax error on token "{", SwitchLabels expected after this token

		at com.flow.flow.main(flow.java:199)*/

//ex10
/*public class flow
{
public static void main(String[] args) {
	int x=10;
	int y=20;
	switch(x)
	{
	case 10:
		System.out.println(10);
		break;
	case y:
		System.out.println(20);
		break;
	}
	}
}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
case expressions must be constant expressions

at com.flow.flow.main(flow.java:222)*/

//ex11
/*public class flow
{
public static void main(String[] args) {
	byte b=10;
	switch(b)
	{
	case 10:
	    System.out.println("10");
	    break;
	case 100:
		System.out.println(100);
		break;
	case 1000:
		System.out.println(1000);
		break;
	}
	}
}

output:
Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
Type mismatch: cannot convert from int to byte

at com.flow.flow.main(flow.java:248)*/

//ex12
/*public class flow
{
public static void main(String[] args) {
	int x=10;
	switch(x)
	{
	case 97:
	    System.out.println("97");
	    break;
	case 98:
		System.out.println(98);
		break;
	case 99:
		System.out.println(99);
		break;
	case 99:
		System.out.println(99);
		break;
	}
	}
}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
		Duplicate case
		Duplicate case

		at com.flow.flow.main(flow.java:274)*/

//ex13
/*public class flow
{
public static void main(String[] args) {
	switch(x)
	{
	default:
	    System.out.println("def");
	    
	case 0:
		System.out.println(0);
		break;
	case 1:
		System.out.println(1);
	case 2:
		System.out.println(2);
	}
	}
}

output:
	Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		x cannot be resolved to a variable

		at com.flow.flow.main(flow.java:295*/

//ex14
/*public class flow
{
public static void main(String[] args) {
	while(true)
	{
		System.out.println("hello");
	}
}
}

output:
	hello
	hello
	hello
	.....*/