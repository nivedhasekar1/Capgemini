package com.thread;

class Account
{
	public int balance;
	
	public Account()
	{
		balance=5000;
	}
	public synchronized void withdraw(int bal)
	{
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		balance=balance-bal;
		System.out.println("amount withdrawn=" +bal);
		System.out.println("remaining balance=" +balance);
	}

public synchronized void deposit(int bal){
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	balance=balance+bal;
	System.out.println("amount deposited=" +bal);
	System.out.println("remaining deposited=" +balance);
}
public synchronized void enquiry(){
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	System.out.println("available balance=" +balance);
}}
class Transaction implements Runnable
{
	Account obj;
	Transaction(Account a)
	{
		obj =a;
	}
	public void run(){
		obj.withdraw(500);
		obj.deposit(1000);
		obj.enquiry();
	}
}

public class ThreadSyn {
public static void main(String[] args) throws Exception {
	Account a=new Account();
	Transaction t=new Transaction(a);
	Thread t1=new Thread(t);
	Thread t2=new Thread(t);
	t1.start();
	t2.start();
}
}
