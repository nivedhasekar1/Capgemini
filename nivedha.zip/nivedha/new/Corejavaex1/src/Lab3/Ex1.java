package Lab3;
import java.util.*;

public class Ex1 {
   int getSecondSmallest(int[] a)
	{
	Arrays.sort(a);
	System.out.println("The second smallest element in the array is..");
	return a[1];	 
	}

	public static void main(String[] args) 
	{

		 Scanner sc=new Scanner(System.in);
		 System.out.println("Enter the size of an array..");
			int size=Integer.parseInt(sc.nextLine());
			
		 System.out.println("Enter the elements for the array..");
			int a[]=new int[size];
			int i=0;
			
			for( i=0;i<size;i++)
			{
				 a[i]=sc.nextInt();
			} 	
			
		sc.close();
		Ex1 s=new Ex1();
		System.out.println(s.getSecondSmallest(a));
	}
}
