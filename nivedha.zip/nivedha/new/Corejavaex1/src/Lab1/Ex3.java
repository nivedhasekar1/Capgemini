package Lab1;
import java.util.Scanner;
class Test3
{
	boolean check(int n){
		boolean flag=false;
		int currentdigit=n%10;
		n=n/10;
		while(n>0)
		{
			if(currentdigit<n % 10){
				flag=true;
				break;
			}
			currentdigit=n % 10;
			n=n/10;
		}
		if(flag){
			System.out.println("not a increasing number");
		}
		else{
			System.out.println("increasing number");
		}
		return flag;		
	}
}
public class Ex3 {
	public static void main(String[] args)
	{
		Test3 t=new Test3();
		System.out.println("enter a number:");
		Scanner s=new Scanner(System.in);
		int n=s.nextInt();
		t.check(n);
		s.close();
	}
}