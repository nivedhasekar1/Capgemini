package Lab1;
public class Ex2 {
int calculateddifference(int n)
{
	int a=0,sum=0;
	for(int i=1;i<=n;i++)
	{
		a=a+i;
		sum=sum+(i*i);
	}
	sum=(a*a)-sum;
	return sum;
}
public static void main(String[] args) {
	Ex2 e=new Ex2();
	System.out.println(e.calculateddifference(3));
}}