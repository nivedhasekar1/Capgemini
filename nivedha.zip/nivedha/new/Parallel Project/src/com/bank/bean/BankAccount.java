package com.bank.bean;

public class BankAccount {
	private long accountNo;

	private String name;
	private String branch;
	private String accType;
	private long balance;
	private long moblieNo;

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public long getBalance() {
		return balance;
	}

	public void setBalance(long balance) {
		this.balance = balance;
	}

	public long getMoblieNo() {
		return moblieNo;
	}

	public void setMoblieNo(long moblieNo) {
		this.moblieNo = moblieNo;
	}

	@Override
	public String toString() {
		return "BankAccount [accountNo=" + accountNo + ", name=" + name + ", branch=" + branch + ", accType=" + accType
				+ ", balance=" + balance + ", moblieNo=" + moblieNo + "]";
	}

}