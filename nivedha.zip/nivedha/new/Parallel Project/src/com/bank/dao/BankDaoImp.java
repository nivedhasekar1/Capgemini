package com.bank.dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.bank.bean.BankAccount;
import com.bank.bean.Transaction;
import com.bank.exception.AccountNotFoundException;

public class BankDaoImp implements BankDao {

	Map<Long, BankAccount> accounts = new HashMap<Long, BankAccount>();
	Map<Transaction, Long> tranInfo = new HashMap<Transaction, Long>();

	@Override
	public void insertBankAccount(BankAccount account) {
		//creating new account
		
		accounts.put(account.getAccountNo(), account);

	}

	@Override
	public BankAccount retrieveBankAccount(long accountNo) {
		//retrieving the account details using account number
		
		BankAccount bank3 = accounts.get(accountNo);
		if(bank3 == null){
			throw new AccountNotFoundException("Enter Valid Account No:");
		}
		return bank3;

	}

	@Override
	public BankAccount depositAmount(long accno2, long depositAmount) {
		//depositing the amount in given account number
		
		BankAccount b3 = accounts.get(accno2);
		if(b3 == null){
			throw new AccountNotFoundException("No Account Found...Enter Valid Account No");
		}else{
		long balance2 = b3.getBalance();
		long balance3 = balance2 + depositAmount;
		b3.setBalance(balance3);

		Transaction bankTran = new Transaction();
		bankTran.setTransactionType("saving");
		bankTran.setTransctionId(654689);
		bankTran.setToAccount(accno2);
		bankTran.setOldBalance(balance2);
		bankTran.setNewBalance(balance3);

		tranInfo.put(bankTran, accno2);
		}
		return b3;
		
	}

	@Override
	public BankAccount withdrawAmount(long accno3, long withdrawAmount) {
		//withdraw the amount in given account number
		
		BankAccount b4 = accounts.get(accno3);
		if(b4 == null){
			throw new AccountNotFoundException("No Account Found...Enter Valid Account No");
		}else{
		long bal2 = b4.getBalance();
		long bal3 = bal2 - withdrawAmount;
		b4.setBalance(bal3);

		Transaction bankTran = new Transaction();
		bankTran.setTransctionId(654731);
		bankTran.setFromAccount(accno3);
		bankTran.setOldBalance(bal2);
		bankTran.setNewBalance(bal3);
		tranInfo.put(bankTran, accno3);
		}
		return b4;

	}

	@Override
	//for transfer amount from given accounts
	public BankAccount fundTransfer(long accNo1, long accNo2, long transferAmount) {
		BankAccount acc1 = accounts.get(accNo1);
		
		BankAccount acc2 = accounts.get(accNo2);
		
		long oldBal1 = acc1.getBalance();
		long oldBal2 = acc2.getBalance();
		long newBal1 = oldBal1 - transferAmount;
		long newBal2 = oldBal2 + transferAmount;
		acc1.setBalance(newBal1);
		acc2.setBalance(newBal2);

		Transaction bankTran = new Transaction();
		bankTran.setTransctionId(654765);
		bankTran.setFromAccount(oldBal1);
		bankTran.setToAccount(oldBal2);
		bankTran.setOldBalance(accNo1);
		bankTran.setNewBalance(accNo2);
		tranInfo.put(bankTran, accNo1);

		return acc1;

	}

	@Override
	//displaying the transcation details
	public List<Transaction> printTransaction() {
		
		System.out.println("No Of Transations:" + tranInfo.size());
		List<Transaction> list = new ArrayList<Transaction>(tranInfo.keySet());
		return list;
	}

	
}
