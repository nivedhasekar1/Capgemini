package com.bank.dao;

import java.util.List;

import com.bank.bean.BankAccount;
import com.bank.bean.Transaction;

public interface BankDao {

	void insertBankAccount(BankAccount account);//creating new account

	BankAccount retrieveBankAccount(long accountNo);
	//retrieving the account details using account number

	BankAccount depositAmount(long accno2, long depositAmount);
	//depositing the amount in given account number

	BankAccount withdrawAmount(long accno3, long withdrawAmount);
	//withdraw the amount in given account number

	BankAccount fundTransfer(long accNo1, long accNo2, long transferAmount);
	//for transfer amount from given accounts

	List<Transaction> printTransaction();
	//displaying the transcation details
	
}
