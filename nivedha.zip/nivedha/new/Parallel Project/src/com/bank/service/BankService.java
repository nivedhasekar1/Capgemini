package com.bank.service;

import java.util.List;

import com.bank.bean.BankAccount;
import com.bank.bean.Transaction;

public interface BankService {

	BankAccount retrieveBankAccount(long accountNo);

	void insertBankAccount(BankAccount account);

	BankAccount depositAmount(long accno2, long depositAmount);

	BankAccount withdrawAmount(long accno3, long withdrawAmount);

	BankAccount fundTransfer(long accNo1, long accNo2, long transferAmount);

	List<Transaction> printTransaction();
	
	boolean validation(String name);
	
	boolean mobileValidation(long mobileNo);
	
}
