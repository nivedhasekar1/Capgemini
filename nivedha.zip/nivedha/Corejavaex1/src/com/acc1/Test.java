
package com.acc1;
import java.util.*;

public class Test {

		public static void main(String[] args)
		{
			Test t=new Test();
			 String str[] ={"ax","bb","xx"};  
		      	
		      	System.out.println(t);
				String str1 = t.replace("x","  ");  
		        System.out.println(str1);  
		        str1 = str1.replace("x","  ");   
		        System.out.println(str1); 
		        System.out.println(t.replace("x", " "));
			
			
		}

		private String replace(String string, String string2) {
			// TODO Auto-generated method stub
			return null;
		}}