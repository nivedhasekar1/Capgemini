package com.acc1;
import com.acc.Test;
class Test1 
{
public static void main(String[] args){
	Test t=new Test();
System.out.println(t.a);
}
}