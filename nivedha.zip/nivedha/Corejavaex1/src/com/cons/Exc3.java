package com.cons;
public class Exc3 {
	public static void main(String[] args) {
		try{
			int a[]=new int[5];
			a[4]=30/3;
			String s="hi";
			int x=Integer.parseInt(s);
			//System.out.println(s.length());
			System.out.println("no error "+a[4]+" "+x);
		}catch(ArrayIndexOutOfBoundsException ae)
		{
		System.out.println("please enter valid index");
	    }
		catch(ArithmeticException e)
		{
		System.out.println("don't enter zero ");
    	} 
		catch(NumberFormatException e) 
		{
		System.out.println("we can't convent string to number"+e);
	    }
		catch(Exception e)
		{
		System.out.println("unable to find length of the string"+e);
		//e.printStackTrace();
		//System.out.println(e.getMessage());
	    }
		finally{System.out.println("executes every time");
		}
		System.out.println("remaining code");
	}
} 