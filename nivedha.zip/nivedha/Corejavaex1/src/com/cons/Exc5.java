package com.cons;
class Myex extends Exception
{
	
	public Myex(String errormsg)
	{
		super(errormsg);
	}
	}
	
public class Exc5 
{
	static void validation(int age1) throws Myexc
	{
		int mark = 0;
		if (mark<35)
	throw new Myexc("you are pass");
		else
			System.out.println("you are fail");
	}
	public static void main(String[] args) throws Myexc
	{
		Exc4.validation(13);
System.out.println("rest of code......");
	}

}