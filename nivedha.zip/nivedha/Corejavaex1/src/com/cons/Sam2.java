package com.cons;

public class Sam2 {
	public Sam2(){
		System.out.println("default cons");
	}
	public Sam2(String name){
		System.out.println("string param cons");
	}
	public Sam2(int id,int b){
		System.out.println("int param cons");
	}
	void m1()
	{
		System.out.println("method");
	}
	public static void main(String[] args) {
		Sam2 s=new Sam2("hi");
		Sam2 s1=new Sam2(13,7);
		Sam2 s2=new Sam2();
		s.m1();
		s1.m1();//method will be printed again
		s2.m1();//method will be printed again
	}

}
