package com.cons;
class Myexc extends Exception
{
	
	public Myexc(String errormsg)
	{
		super(errormsg);
	}}
	
public class Exc4 {
	static void validation(int age1) throws Myexc
	{
		if (age1<18)
	throw new Myexc("you are not eligable to vote");
		else
			System.out.println("you are eligable to vote");
	}
	public static void main(String[] args) throws Myexc{
		Exc4.validation(13);
System.out.println("rest of code......");
	}
}
