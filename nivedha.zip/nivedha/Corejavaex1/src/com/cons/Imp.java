package com.cons;

	 interface Test9
	 {
		 void m2();
		 void m3();
	 }
	 public class Imp implements Test9
	 {
		 public void m1(){
				System.out.println("test class");
			}
		 @override
		 public void m3(){
			 System.out.println("welcome");
		 }
		 @override
		 public void m2(){
		 }
		 public static void main(String[] args) {
			Imp s=new Imp();
			s.m1();
			s.m2();
			s.m3();
		}
		 }
	 
	
