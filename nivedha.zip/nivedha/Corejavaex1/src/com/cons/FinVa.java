/*package com.cons;

public class FinVa {
	public static void main(String[] args) {
		
	
	final int a=10;
	a=a++;
	}	

}
output:
Exception in thread "main" java.lang.Error: Unresolved compilation problems: 
	The final local variable a cannot be assigned. It must be blank and not using a compound assignment
	The final local variable a cannot be assigned. It must be blank and not using a compound assignment

	at com.cons.FinVa.main(FinVa.java:8)*/

package com.cons;
class Hi{
	int a= 123;
	public void add(){
	   	a=++a;
    	 int b=11;
		System.out.println(a+b);
	}
}
public class FinVa extends Hi {
	@override
	final public void add(){
		 a = --a;
		int b=31;
		System.out.println(a+b);
	}
	public static void main(String[] args) {
		FinVa f=new FinVa();
		f.add();	
	}
}