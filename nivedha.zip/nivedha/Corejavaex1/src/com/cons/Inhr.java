package com.cons;
class Fir
{
	void m1()
	{
		System.out.println("class a");
	}
	void m2()
	{
		System.out.println("class b");
	}
}
class Sec
{
	void m3()
	{
		System.out.println("class s");
	}
}
class thi extends Sec
{
	void m4()
	{
		System.out.println("class d");
	}
}

public class Inhr extends Fir {
	public static void main(String[] args) {
		System.out.println(" level");
		Inhr n=new Inhr();
		n.m1();
		n.m2();
	}

}
