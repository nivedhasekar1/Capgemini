package com.cons;
class A
{
	void m1()
	{
		System.out.println("class a");
	}
	void m2()
	{
		System.out.println("class b");
	}
}

public class Sin extends A {
	public static void main(String[] args) {
		System.out.println("single level");
		Sin s=new Sin();
		s.m1();
		s.m2();
	}

}
