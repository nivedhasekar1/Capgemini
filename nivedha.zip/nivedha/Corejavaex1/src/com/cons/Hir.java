package com.cons;
class S
{
	void m1()
	{
		System.out.println("class s");
	}
}
class D extends S
{
	void m2()
	{
		System.out.println("class d");
	}
}
public class Hir extends S{
	public static void main(String[] args) {
		System.out.println("hierarchy");
		Hir h=new Hir();
		h.m1();
	}

}