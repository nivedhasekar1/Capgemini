package com.cons;

public class Emp {
	public static void main(String[] args) {
		Enc e=new Enc();
		e.setAtmpin(3456);
		e.setEmpid(13);
		e.setName("nivedha");
		e.setSal(15000);
		System.out.println(e.getName());
		System.out.println(e.getEmpid());
		System.out.println(e.getSal());
		System.out.println(e.getAtmpin());
	}

}
