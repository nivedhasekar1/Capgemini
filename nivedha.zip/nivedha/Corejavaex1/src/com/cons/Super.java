package com.cons;
class Q{
int a=10;
public Q ()
{
	this(37);
	System.out.println("default");
	}
Q(int a)
{
	//this();
	System.out.println("parent class:"+a);
}
public void m1()
{
	System.out.println("parent class method");
}
}public class Super extends Q {
static int a=37;
Super()
{
	super();
	super.m1();
	this.m1();
System.out.println(this.a);
System.out.println(super.a);
System.out.println(this);
System.out.println("child class");
}
public void m1()
{
	System.out.println("child class method");
}
public static void main(String[] args) {
	Super e= new Super();
	System.out.println(e);
	Q p=new Q(12);
}
}