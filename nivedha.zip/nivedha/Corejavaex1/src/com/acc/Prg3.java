package com.acc;

public class Prg3 {

			public static void main(String[] args) 
			{
				String s1 ="capgemini";
				
				String s2 ="Capgemini";
				System.out.println(s1.matches(s2));
	         }
}