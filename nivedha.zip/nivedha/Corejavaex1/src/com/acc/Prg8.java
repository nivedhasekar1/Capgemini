package com.acc;
public class Prg8 {
	
		public static void main(String args[])
		{
	String text="hi hello";
	String text1;
	text1=text.replace(text.substring(4,8),text.substring(4,8).toUpperCase()); 
	System.out.println(text1);

	}
	}
