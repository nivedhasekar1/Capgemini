package com.cap;

public class prime {
	public static void main(String[] args) {
        int n=17,t;
        {
	for(int i=2;i<=n/2;i++)
	{
		t=n%i;
	if(t==0)
	{
		System.out.println("not a prime no");
	    break;
    	}
	else
	{
		System.out.println(" prime no");
	}
	}
        }
        }
	}
