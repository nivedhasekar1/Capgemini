package com.cap;
import java.util.Scanner;

public class test2 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("enter emp id:");
		int a=sc.nextInt();
		System.out.println("enter emp name:");
		String s=sc.next();
		System.out.println("enter emp salary:");
		int c=sc.nextInt();
		System.out.println("enter emp address:");
		String d=sc.next();
		System.out.println("emp id:"+a);
		System.out.println("emp name:"+s);
		System.out.println("emp salary:"+c);
		System.out.println("emp address:"+d);
		d+= sc.nextLine();//if we give 2 words it will display the 1st word
	sc.close();
	}

}
