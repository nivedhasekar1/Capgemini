package com.coll;

import java.util.Vector;

public class Vect {
	public static void main(String[] args) {
		Vector v=new Vector();
		v.addElement(11);
		v.addElement(13);
		v.addElement(11);
		v.addElement(13);
		v.addElement(11);
		v.addElement(13);
		v.addElement(11);
		v.addElement(13);
		v.addElement(11);
		v.addElement(13);
		v.addElement(11);
		v.addElement(13);
		v.removeElement(11);
		v.removeElementAt(1);
		v.removeAllElements();
		System.out.println(v.capacity());
		
	}

}
