package com.coll;

import java.util.ArrayList;
import java.util.Iterator;
public class Itera {
public static void main(String[] args) {
	 ArrayList a = new ArrayList();
	a.add("kaviya");
	a.add("pradi");
	a.add("mercy");
	a.add("nandhini");
	a.add("merlin");
	a.add("savitha");

	System.out.println(a);
	Iterator itr1=a.iterator();
	while(itr1.hasNext())
	{
		
		String name=(String) itr1.next();
		if(name.equals("kaviya"))
				{
			itr1.remove();
				}
		else
		{
		System.out.println(name);
		}
	}
}
}
