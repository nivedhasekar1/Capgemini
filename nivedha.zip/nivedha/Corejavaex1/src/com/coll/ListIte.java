package com.coll;
	import java.util.ArrayList;
	import java.util.Iterator;
	import java.util.ListIterator;
	public class ListIte {
	public static void main(String[] args) {
		 ArrayList a = new ArrayList();
		a.add("kaviya");
		a.add("pradi");
		a.add("mercy");
		a.add("kaviya");
		System.out.println(a);
		ListIterator itr1=a.listIterator();
		
		while(itr1.hasNext())   //in forward direction
		{
			System.out.println(itr1.next()+" ");
		}
		while(itr1.hasPrevious()) //in backward direction
		{
	String val=(String) itr1.previous();
	if(val.equals("kaviya")){
		itr1.set("cap");
		itr1.add("hi");
		System.out.println(itr1.next());
		itr1.previous();
	}
	else
	{
		System.out.println(val);
	}
}}}
