package com.coll;
import java.util.Stack;
public class Stac {

	
		public static void main(String[] args) {
			
			Stack s=new Stack();
			s.push(3);
			s.push(7);
			s.push("hi");
			s.push(13);
			System.out.println(s);
			System.out.println(s.pop());
		    System.out.println(s.isEmpty());
			System.out.println(s.peek());
		}	
		}

