package com.coll;

import java.util.TreeSet;

public class Tree {
public static void main(String[] args) {
	TreeSet s=new TreeSet();
	
	//s.add("hi");
	//s.add("anu");
	//s.add("welcome");
	
	s.add(3);
	s.add(7);
	s.add(1);
	System.out.println(s);//by default asc
	System.out.println(s.descendingSet());//for desc
	
}
}
