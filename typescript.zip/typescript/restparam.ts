function add(x:number,...y:number[]):number{
    let result =x;
    for(var i=0;i<y.length;i++){
        result +=y[i];
    }
    return result;
}
let result1=add(3,7);
let result2=add(1,9,5,8);
console.log(result1);
console.log(result2);
