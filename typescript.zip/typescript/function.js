function add(a, b) {
    return a + b;
}
var sum = add(100, 37);
var sum1 = add('welcome', 200);
console.log(sum);
console.log(sum1);
var x;
//x='welcome';
function add1(a, b) {
    return a + b;
}
var sum4 = add1(27, 31);
//var add2=add('welcome',10);
function add2(a, b, c) {
    return a + b + c;
}
var sum2 = add2(100, 200);
var sum3 = add2(13, 17, 19);
console.log(sum2);
console.log(sum3);
function add3(a, b, c, d) {
    return a + b + c + d;
}
var hel = add3(1, 2, 3, 4);
var hel = add3(1, 2, 3);
function add4(a, b, c, d) {
    return a + b + c + d;
}
