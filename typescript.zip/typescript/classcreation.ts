class person
{
    firstname:string;
    lastname:string;
}
var p=new person();
p.firstname="Nivedha";
p.lastname="Sekar";
console.log(p.firstname+" "+p.lastname);