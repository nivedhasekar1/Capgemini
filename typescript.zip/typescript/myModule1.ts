import { Student,Employee} from "./myModule";
let st=new Student(1,"nivetha");
let result1=st.showDetails();
console.log("student details:" +result1);
let emp = new Employee("qwerty","hello");
let result2=emp.showDetails();
console.log("employee details:" +result2);