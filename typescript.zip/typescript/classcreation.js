var person = /** @class */ (function () {
    function person() {
    }
    return person;
}());
var p = new person();
p.firstname = "Nivedha";
p.lastname = "Sekar";
console.log(p.firstname + " " + p.lastname);
