let firstname: string="javascript";
let site: string="www.cap.com";
let str='hello,my name is:' +firstname+'and my site is:' +site
console.log(str);
let str2=`hello,my name is:${firstname}and my site is:${site}`;
console.log(str2);
