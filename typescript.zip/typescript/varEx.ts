var a:number=11;
var b:number;
var c:string;
var d:boolean;
var e=undefined;
var f=null;

a=123;
b=234;
c="welcome";
d=false;
console.log(a+b);
