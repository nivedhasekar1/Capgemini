function add(x:number,y: number):number{
    return x+y;
}
let sum=function(x: number,y:number): number{
    return x+y;    
};
add(13,17);
sum(11,19);
let sum1=(x:number,y:number)=>x+y;
sum1(123,234);
let sum2=(x:number,y:number)=>{return x+y};
sum2(123,234);
let sum3=(x,y)=>x+y;
sum3(37,91);
let sum4=()=>console.log("function with out return type");
sum4();
