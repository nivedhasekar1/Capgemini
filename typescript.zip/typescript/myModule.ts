export class Employee{
    constructor(private firstname:string, private lastname:string){
    }
    showDetails(){
        return this.firstname + ", " + this.lastname;
    }
}
export class Student {
    constructor(private rollno:number,private name:string){
        
    }
        showDetails(){
            return this.rollno + ", " + this.name;

        
    }
}