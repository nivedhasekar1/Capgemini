var Emp = /** @class */ (function () {
    function Emp(empid, name) {
        Emp.empid = empid;
        this.name = name;
    }
    Emp.prototype.dispalyDetails = function () {
        return Emp.empid + " : " + this.name;
    };
    return Emp;
}());
Emp.empid = 12345;
var emp1 = new Emp(123, "jam");
console.log(emp1.dispalyDetails());
