function add(x, y) {
    return x + y;
}
var sum = function (x, y) {
    return x + y;
};
add(13, 17);
sum(11, 19);
var sum1 = function (x, y) { return x + y; };
sum1(123, 234);
var sum2 = function (x, y) { return x + y; };
sum2(123, 234);
var sum3 = function (x, y) { return x + y; };
sum3(37, 91);
var sum4 = function () { return console.log("function with out return type"); };
sum4();
