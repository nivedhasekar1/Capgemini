class Emp{
    static empid:number;
    name:string;
    constructor(empid:number,name:string){
        Emp.empid=empid;
        this.name=name;
    }
    dispalyDetails(){
        return Emp.empid + " : " +this.name;
    }
}
Emp.empid=12345;
var emp1=new Emp(123,"jam");
console.log(emp1.dispalyDetails());
