package com.cap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;
import com.cap.service.BankService;
import com.cap.service.BankServiceImp1;


public class BankDaoImp1 implements BankDao {
    //BankService serviceObj=new BankServiceImp1();
    
	@Override
	public int createAccount(BankDetails bankdetails) {
		Connection conn=DBConnect.getConnection();
		PreparedStatement stmt;
		int accNo = 0;
		try{
			
		stmt=conn.prepareStatement("insert into bank values(b.nextval,?,?,?,?,?)");
		
		
		stmt.setString(1, bankdetails.getCustName());
		stmt.setLong(2, bankdetails.getCustMobNum());
		stmt.setString(3, bankdetails.getCustBranch());
		stmt.setLong(4, bankdetails.getAccBal());
		stmt.setString(5, bankdetails.getAccType());
		
		int result=stmt.executeUpdate();
	     if(result>0){
	             PreparedStatement p1=conn.prepareStatement("select b.currval from dual");
	             ResultSet rs=p1.executeQuery();
	             rs.next();
	             accNo = rs.getInt(1);
	             }

		}
		catch(SQLException e)
		{ 
			e.printStackTrace();
		}
		
		return accNo;
	}
		@Override
	    public long showDetails(long accNum) {
	        
	        Connection conn =DBConnect.getConnection();
	        PreparedStatement stmt1;
	        long balance=0;
	        try {
	        	stmt1 = conn.prepareStatement("select accbal from bank where accnum=?");
	        	stmt1.setLong(1,accNum);
	            ResultSet rs=stmt1.executeQuery();
	            rs.next();
	         balance =rs.getInt(1);
	        } catch (SQLException e){
	            e.printStackTrace();
	        }
	        
	        return balance;
	    }
	

		@Override
	    public long depositDetails(long accNum, long depAcc) 
	    {
	        Connection conn;
	        long bal = 0;
	        int value = 0;
	        long bal1 =0;
	        try {
	            conn = DBConnect.getConnection();
	            PreparedStatement stmnt = conn.prepareStatement("select accBal from bank where accNum=?");
	            stmnt.setLong(1, accNum);
	            ResultSet set = stmnt.executeQuery();
	            set.next();
	            bal = set.getLong(1);
	            bal1 = bal + depAcc;
	            System.out.println(bal);

	 

	            PreparedStatement stmnt1 = conn.prepareStatement("update bank set accBal=? where accNum=?");
	            stmnt1.setLong(1, bal1);
	            stmnt1.setLong(2, accNum);
	            value = stmnt1.executeUpdate();

	 

	            if (value > 0) {
	                PreparedStatement stmt2 = conn
	                        .prepareStatement("insert into transaction values(transEx.nextval,?,?,?,?,?)");
	                stmt2.setString(1, "Withdrawn");
	                stmt2.setLong(2, bal);
	                stmt2.setLong(3, bal1);
	                stmt2.setLong(4, accNum);
	                stmt2.setLong(5, accNum);
	                int result1 = stmt2.executeUpdate();
	            } else {
	                System.out.println("no");
	            }

	 

	        } catch (Exception ae) {
	            System.out.println(ae);

	 

	        }
	        return bal1;

	 

	    }

		@Override
	    public long withdrawDetails(long accNum, long withDraw) {
	        Connection conn;
	        long bal = 0;
	        int value = 0;
	        try {
	            conn = DBConnect.getConnection();
	            PreparedStatement stmnt = conn.prepareStatement("select accBal from bank where accNum=?");
	            stmnt.setLong(1, accNum);
	            ResultSet set = stmnt.executeQuery();
	            set.next();
	            bal = set.getLong(1);
	            bal =bal- withDraw;
	            System.out.println(bal);
	            PreparedStatement stmnt1 = conn.prepareStatement("update bank set accBal=? where accNum=?");
	            stmnt1.setLong(1, bal);
	            stmnt1.setLong(2, accNum);
	            value = stmnt1.executeUpdate();
	            
	            if (value > 0) {
	                PreparedStatement stmt2 = conn
	                        .prepareStatement("insert into transaction values(transEx.nextval,?,?,?,?,?)");
	                stmt2.setString(1, "Withdrawn");
	                stmt2.setLong(2, bal);
	                stmt2.setLong(3, bal);
	                stmt2.setLong(4, accNum);
	                stmt2.setLong(5, accNum);
	                int result1 = stmt2.executeUpdate();
	            } else {
	                System.out.println("no");
	            }

	 

	        } catch (Exception ae) {
	            System.out.println(ae);
	            if (value > 0) {
	                System.out.println("Withdrawn");
	            }
	        }
	        return bal;
	    }
	
	@Override
    public long fundTransfer(long accNum4, long accNum5, long fundTrans) 
    {
        Connection conn;
        long bal = 0;
        int value = 0;
        long value2 = 0;
        long bal1 =0;
        try {
            conn = DBConnect.getConnection();
            PreparedStatement stmnt = conn.prepareStatement("select accBal from bank where accNum=?");
            stmnt.setLong(1, accNum4);
            ResultSet set = stmnt.executeQuery();
            set.next();
            bal = set.getLong(1);
            bal1 =bal - fundTrans;
            PreparedStatement stmnt1 = conn.prepareStatement("update bank set accBal=? where accNum=?");
            stmnt1.setLong(1, bal1);
            stmnt1.setLong(2, accNum4);
            value = stmnt1.executeUpdate();

 

            if (value > 0) {
                PreparedStatement stmt2 = conn
                        .prepareStatement("insert into transaction values(transEx.nextval,?,?,?,?,?)");
                stmt2.setString(1, "Fund Transfer");
                stmt2.setLong(2, bal);
                stmt2.setLong(3, bal1);
                stmt2.setLong(4, accNum4 );
                stmt2.setLong(5, accNum5);
                int result1 = stmt2.executeUpdate();
            } else {
                System.out.println("no");
            }
            
            
            PreparedStatement stmnt2 = conn.prepareStatement("select accBal from bank where accNum=?");
            stmnt2.setLong(1, accNum5);
            ResultSet set1 = stmnt2.executeQuery();
            set1.next();
            bal = set.getLong(1);
            bal =bal+ fundTrans;
            PreparedStatement stmnt3 = conn.prepareStatement("update bank set accBal=? where accNum=?");
            stmnt3.setLong(1, bal);
            stmnt3.setLong(2, accNum5);
            value = stmnt3.executeUpdate();
            if (value > 0) {
                PreparedStatement stmt2 = conn
                        .prepareStatement("insert into transaction values(transEx.nextval,?,?,?,?,?)");
                stmt2.setString(1, "Fund Transfer");
                stmt2.setLong(2, bal);
                stmt2.setLong(3, bal1);
                stmt2.setLong(4, accNum4 );
                stmt2.setLong(5, accNum5);
                int result1 = stmt2.executeUpdate();
            } else {
                System.out.println("no");
            }
            
            
            
    
            PreparedStatement stmnt4 = conn.prepareStatement("select accBal from bank where accNum=?");
            stmnt4.setLong(1,accNum4);        
            ResultSet values=stmnt.executeQuery();
            values.next();
            value2=values.getLong(1);
        }
        catch (Exception ae) {
            System.out.println(ae);
        }

 

        return value2;
    }
    
	@Override
    public void printTransactions() {
       
		BankTransactions bt=new BankTransactions();   
         
            Connection conn=DBConnect.getConnection();
            try {
                 PreparedStatement stmt=conn.prepareStatement("select * from transaction");
                ResultSet s= stmt.executeQuery();
                while(s.next())
                {
                long transId=s.getLong(1);
                String transType=s.getString(2);
                long transOldBal=s.getLong(3);
                long fromAcc=s.getLong(4);
                long toAcc=s.getLong(5);
                long transNewBal=s.getLong(6);
       
                bt.setTransId(transId);
                bt.setFromAcc(fromAcc);
                bt.setToAcc(toAcc);
                bt.setTransOldBal(transOldBal);
                bt.setTransNewBal(transNewBal);
                bt.setTransType(transType);
                System.out.println(bt);
           
                }
            }
           
            catch (Exception e) {
               
                e.printStackTrace();
            }
       
    }
    
}