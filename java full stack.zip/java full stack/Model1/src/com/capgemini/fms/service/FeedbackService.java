package com.capgemini.fms.service;

import java.util.Map;

import com.capgemini.fms.dao.FeedbackDAO;
import com.capgemini.fms.dao.IFeedbackDAO;

public class FeedbackService implements IFeedbackService{

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
		  IFeedbackDAO dao=new FeedbackDAO();
		 return dao.addFeedbackDetails(name, rating, subject);
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean subName(String subject) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean rateNum(int rating) {
		// TODO Auto-generated method stub
		return false;
	}

	

}
