package com.capgemini.fms.ui;

import java.util.Scanner;

import com.capgemini.fms.bean.Feedback;
import com.capgemini.fms.service.FeedbackService;
import com.capgemini.fms.service.IFeedbackService;


public class Client {

	static IFeedbackService service= new FeedbackService();
	 static Scanner scanner = new Scanner(System.in);
	
	
	public static void main(String[] args) {
		while(true)
		{
			System.out.println("Choose the option:");
			System.out.println("1.add feedback");
			System.out.println("2.print feedback report");
			System.out.println("3.exit");
			
			int choose=scanner.nextInt();
			switch(choose){
			case 1:
				System.out.println("enter teacher name:");
				String tname=scanner.next();
				
				System.out.println("Enter subject name:");
				String sname=scanner.next();
				System.out.println("enter rating");
				int rating = scanner.nextInt();
				Feedback fb=new Feedback();
				fb.setTeacherName(tname);
				fb.setTopic(sname);
				fb.setRating(rating);
				System.out.println("added successfully");
				break;
				
			case 2:
				break;
				
			case 3:
				  System.out.println("Thanks for using our Application");
	                System.exit(0);
				}}}}
			

