package com.capgemini.fms.dao;

import java.util.HashMap;
import java.util.Map;

public class FeedbackDAO implements IFeedbackDAO{
	Map<String,Integer> MathFeedbackMap = new HashMap<String,Integer>();
	Map<String,Integer> EnglishFeedbackMap = new HashMap<String,Integer>();

	@Override
	public Map<String, Integer> addFeedbackDetails(String name, int rating, String subject) {
	

		MathFeedbackMap.put(name,rating);
		EnglishFeedbackMap.put(name,rating);
		return MathFeedbackMap;
	}

	@Override
	public Map<String, Integer> getFeedbackReport() {
		EnglishFeedbackMap.putAll(MathFeedbackMap);
		
		return EnglishFeedbackMap;
	}

}
