package com.collections;


	

	import java.util.concurrent.ExecutorService;
	import java.util.concurrent.Executors;

	public class ThreadCache {
	public static void main(String[] args) {
		ExecutorService service = Executors.newCachedThreadPool();
		
		for(int i=0;i<100;i++)
		{
			service.execute(new Task1());
		}
		System.out.println("thread name:"+Thread.currentThread().getName());

	}
	}
	class Task1 implements Runnable{
		@Override
		public void run() {
			System.out.println("thread name:"+Thread.currentThread().getName());
			
		}
	}

