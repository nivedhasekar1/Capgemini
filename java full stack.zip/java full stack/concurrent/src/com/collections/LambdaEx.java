package com.collections;

@FunctionalInterface

interface Favorite
{
	public void color(); 
	
}
public class LambdaEx {

	public static void main(String[] args) {
		Favorite f=()->System.out.println("my favourite color is:blue");
		f.color();
	}
}
