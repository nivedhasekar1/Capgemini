package com.collections;

import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListEx1 extends Thread{

	static CopyOnWriteArrayList al = new CopyOnWriteArrayList();
	@Override
	public void run() {
		try{
			Thread.sleep(3000);
		}catch(InterruptedException e){
			//e.printStackTrace();
		}
		System.out.println("child thread");
		al.add("c");
	}
		public static void main(String[] args) throws InterruptedException {
			al.add("a");
			al.add("b");
			CopyOnWriteArrayListEx1 c = new CopyOnWriteArrayListEx1();
			c.start();
			Iterator itr=al.iterator();
			while(itr.hasNext()){
				String values=(String) itr.next();
				System.out.println("main thread iterating values:"+values);
				Thread.sleep(3000);
			}
			System.out.println(al);
		}
	}

