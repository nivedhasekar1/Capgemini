package com.collections;

import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashMapEx {
	public static void main(String[] args) {
		ConcurrentHashMap<Integer, String> cm=new ConcurrentHashMap<Integer, String>();
		cm.put(10, "hi");
		cm.put(20, "jam");
		cm.put(30, "ramya");
		cm.put(40, "hello");
		System.out.println(cm);
		
		cm.putIfAbsent(20, "anu");
		System.out.println(cm);
		cm.remove(30, "hi");
		cm.replace(10, "hi", "mercy");
		System.out.println(cm);
	}

}
