package com.collections;

import java.util.Scanner;

interface Length{
	public int stringLength(String name);
		
	}

public class LenEx {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("Enter 1st String:");
	String x=s.next();
	
	Length l=name->name.length();
	System.out.println(l.stringLength(x));
	
	
}
	
}
