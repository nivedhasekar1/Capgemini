package com.collections;

import java.util.Scanner;

interface Addtion{
	public int add(int a,int b);
}
public class Add {
	
public static void main(String[] args) {
		{ 
			Scanner s=new Scanner(System.in);
			System.out.println("Enter 1st no:");
			int x=s.nextInt();
			System.out.println("Enter 2st no:");
			int y=s.nextInt();
			
			Addtion f=(a,b)->a+b;
	System.out.println(f.add(x,y));
	}
}
}