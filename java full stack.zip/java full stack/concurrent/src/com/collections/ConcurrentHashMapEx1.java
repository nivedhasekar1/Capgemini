package com.collections;

import java.util.HashMap;
import java.util.Iterator;
import java.util.concurrent.ConcurrentHashMap;
import java.util.*;

public class ConcurrentHashMapEx1 extends Thread{
	
	static ConcurrentHashMap cv=new ConcurrentHashMap ();
	
	@Override
	public void run() {
		try{
			Thread.sleep(3000);
		}catch(InterruptedException e){
			//e.printStackTrace();
		}
		System.out.println("child thread");
		cv.put(10, "hi");
		super.run();
		
	}
	public static void main(String[] args) throws InterruptedException {
		cv.put(20, "hi");
		cv.put(30, "hi");
		cv.put(40, "hi");
		ConcurrentHashMapEx1 ah=new ConcurrentHashMapEx1();
		ah.start();
		Set s=cv.keySet();
		Iterator itr=s.iterator();
		while(itr.hasNext())
		{
			Integer i=(Integer) itr.next();
			System.out.println("main thread");
			System.out.println("current key is:"+i+ "and value:"+cv.get(i));
			Thread.sleep(3000);
		}
		System.out.println(cv);
		
	}

}
