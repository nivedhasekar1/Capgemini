package com.collections;

import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListEx {
	public static void main(String[] args) {
		ArrayList a1=new ArrayList();
		a1.add("x");
		a1.add("y");
		System.out.println(a1);
		CopyOnWriteArrayList co=new CopyOnWriteArrayList();
		co.addIfAbsent("A");
		co.add("b");
		co.addAllAbsent(a1);
		System.out.println(co);
		ArrayList a11=new ArrayList();
		a11.add("x");
		a11.add("y");
		a11.add("z");
		System.out.println(a11);
		co.addAll(a11);
		System.out.println(co);
	}

}
