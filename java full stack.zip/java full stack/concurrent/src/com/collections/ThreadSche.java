package com.collections;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

public class ThreadSche {
	public static void main(String[] args) {
		ScheduledExecutorService service= Executors.newScheduledThreadPool(10);
		
		//service.schedule(new Task(), 10, TimeUnit.SECONDS);
		
		service.scheduleAtFixedRate(new Task3(), 15, 10, TimeUnit.SECONDS);
		
		//service.scheduleWithFixedDelay(new Task3(), 15, 10, TimeUnit.SECONDS);
	}
}
class Task3 implements Runnable{

	
	public void run() {
		Date date=new Date();
		System.out.println(Thread.currentThread().getName()+""+new SimpleDateFormat("HH:mm:ss").format(date));
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
			
		}
		
	}
	

