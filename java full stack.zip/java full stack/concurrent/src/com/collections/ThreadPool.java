package com.collections;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ThreadPool {
public static void main(String[] args) {
	ExecutorService service = Executors.newSingleThreadExecutor();
	
	for(int i=0;i<100;i++)
	{
		service.execute(new Task());
	}
	System.out.println("thread name:"+Thread.currentThread().getName());

}
}
class Task implements Runnable{
	@Override
	public void run() {
		System.out.println("thread name:"+Thread.currentThread().getName());
		
	}
}