package com.java8;

interface A{
	void m1();
	default void m2(){
		System.out.println("interface default method");
	}
	default void m3(){
		System.out.println("interface default method");
	}
}
public class TestDefault implements A{

	@Override
	public void m1() {
		System.out.println("teat default class method");
	}
	@Override
	public void m2() {
		System.out.println("different implementation for interface");
	}
	public static void main(String[] args) {
		TestDefault t=new TestDefault();
		t.m1();
		t.m2();
		t.m3();
	}
}
