package com.java8;

public class ThreadFunEx  {
	public static void main(String[] args)
	{
Runnable r=()->{
	System.out.println(Thread.currentThread());
	for(int i=0;i<=5;i++){
		System.out.println("child class");
	}};
	Thread t= new Thread(r);
	t.start();
	for(int i=0;i<=5;i++){
		System.out.println("main thread");
	}
	System.out.println(Thread.currentThread());		
}
	}
