package com.java8;

import java.util.Scanner;

public class EvenEx {

	    public static void main(String[] args) {    
	        System.out.println("enter any 10 numbers..");
	        Scanner sc=new Scanner(System.in);
	        int array[]=new int[10];
	        for(int i=0;i<10;i++)
	       {
	         array[i]=sc.nextInt();    
	        }
	        System.out.println("Even numbers in array list");
	        for(int i=0;i<10;i++){
	            if(array[i]%2==0)
	            {
	                System.out.println(array[i]);
	            }
	        }}}
	               