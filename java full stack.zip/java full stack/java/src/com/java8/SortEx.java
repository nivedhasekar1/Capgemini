package com.java8;

import java.util.Comparator;
import java.util.TreeMap;

public class SortEx {
public static void main(String[] args) {
	
	Comparator<Integer> c=(i1,i2)->{return (i1<i2)?1:(i1>i2)?-1:0;};
	TreeMap<Integer, String> t=new TreeMap<Integer, String>(c);
	t.put(100, "asd");
	t.put(10, "ert");
	t.put(75, "jhg");
	System.out.println(t);
	
}
}
