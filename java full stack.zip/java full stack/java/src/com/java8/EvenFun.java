package com.java8;

import java.util.function.Predicate;

public class EvenFun {
public static void main(String[] args) {
	int[] values={1,20,2,89,95,31,86};
	Predicate<Integer> pre= i->i%2==0;
	for(int val: values){
		if(pre.test(val)){
			System.out.println(val);
		}
	}
	
	
}
}
