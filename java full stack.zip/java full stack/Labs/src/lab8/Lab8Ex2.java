package lab8;

	import java.io.BufferedReader;
	import java.io.FileReader;
	import java.io.FileWriter;

	public class Lab8Ex2 {
	    public static void main(String args[]) throws Exception {
	        int c = 0;
	        String k = "C:/Users/nivsekar/Desktop/java full stack/Labs/src/lab8/nivedha.txt";
	        char buffer[] = new char[k.length()];
	        k.getChars(0, k.length(), buffer, 0);
	      /*  FileWriter f1 = new FileWriter("C:/users/aggeorge/Desktop/fullstack/Lab exercises/src/labexercise/lab8/linenumber");
	        f1.write(buffer);
	        f1.close();*/
	        FileReader fr = new FileReader(k);
	        BufferedReader br = new BufferedReader(fr);
	        String t;
	        while ((t = br.readLine()) != null) {
	            c++;
	            System.out.println(c + t);
	        }
	        fr.close();
	    }

	}
