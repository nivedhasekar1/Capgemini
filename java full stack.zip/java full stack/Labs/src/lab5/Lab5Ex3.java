package lab5;
	import java.util.Scanner;
	public class Lab5Ex3 {
	    static void prime(int num1)
	     {
	        for (int i = 1; i <=num1; i++) 
	        {   int count=0;
	            for(int num=i;num>=1;num--)
	            {
	                if(i%num==0)
	                {
	                    count=count+1;
	                }
	            }
	            if(count==2)
	            {
	                System.out.println(i);
	            }
	        }
	    }

	 

	    public static void main(String[] args) {
	        System.out.println("Enter the number to get Prime Numbers: ");
	        Scanner sc=new Scanner(System.in);
	        int num1=sc.nextInt();
	        Lab5Ex3.prime(num1);
	        sc.close();  
	    }

	}

