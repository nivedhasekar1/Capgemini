package lab5;


	import java.util.Scanner;

	 

	public class Lab5Ex1 {
	      public static void main(String[] args) 
	      {
	            String colour;
	            Scanner s=new Scanner(System.in);
	            System.out.println("Enter the colour:");
	            colour=s.next();
	            switch(colour){
	            case "Red":
	            case "red":
	                System.out.println("Stop");
	                break;
	            case "Yellow":
	            case "yellow":
	                System.out.println("Ready");
	                break;
	            case "Green":
	            case "green":
	                System.out.println("Go");
	                break;
	            default:
	                System.out.println("There is no related choice is matched");
	            }
	        }
	}

