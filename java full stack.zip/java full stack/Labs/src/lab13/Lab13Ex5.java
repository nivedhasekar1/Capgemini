package lab13;


	import java.util.function.Function;

	 

	public class Lab13Ex5 {
	    public static int factorial(int n) {
	        if (n == 0) {
	            return 1;
	        } else
	            return n * factorial(n - 1);

	 

	    }

	 

	    public static void main(String[] args) {
	        Function<Integer, Integer> fac = Lab13Ex5::factorial;
	        boolean b = fac.apply(5).equals(120);
	        System.out.println(b);
	    }

	 

	}

