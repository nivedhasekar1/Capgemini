package lab3;
	
	public class Lab3Ex2 {
	   
	}
	 

