package com.lab1;

import java.util.Scanner;

public class Lab1Ex3 {
	
	
	    static boolean checkNumber(int number)        
	    {
	        int b=0;
	        String s=Integer.toString(number);
	        char s1;
	        for(int i = 0; i<s.length()-1; i++)
	        {
	            s1=s.charAt(i);
	            if(s1 > s.charAt(i+1))
	            {
	                 b = 1;
	                 break;
	            }
	        }  
	        if(b==1)
	            return false;    
	        else        
	            return true;
	    }
	    public static void main(String[] args) 
	    {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter any number:");
	        int n=sc.nextInt();
	        System.out.println(Lab1Ex3.checkNumber(n));
	    }
	}

	 

	 

	 

	 



