package com.lab1;


	import java.util.Scanner;
	 
	public class Lab1Ex4 {
	
	    
	    static boolean checkNumber(int n) 
	    {
	        if (n==0 || n==1)
	        {
	            return false;
	        }
	        while(n!=1)
	        {
	            if(n%2!=0)
	            {
	                return false;
	            }
	            n=n/2;
	        }
	        return true;
	    }    
	    public static void main(String[] args) 
	    {
	        Scanner sc=new Scanner(System.in);
	        System.out.println("Enter any number:");
	        int n=sc.nextInt();
	        System.out.println(Lab1Ex4.checkNumber(n));
	    }
	}

