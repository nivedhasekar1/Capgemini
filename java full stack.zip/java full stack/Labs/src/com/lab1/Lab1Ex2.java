package com.lab1;
	import java.util.Scanner;
	
	public class Lab1Ex2 {
	
	     static int sum,n,i;
	     public static int calculateDifference(int n)        
	     {
	         int a;
	         int sos=(n*(n+1)*(2*n+1))/6;           
	         a=sos;
	         
	         int b=(n*(n+1))/2;                   
	         int c=b*b;                            
	         sum=c-a;
	         return sum;
	     }
	public static void main(String[] args) 
	{
	         Scanner sc=new Scanner(System.in);
	        System.out.println("Enter any number:");
	        int n=sc.nextInt();
	        System.out.println(Lab1Ex2.calculateDifference(n));
	}
	}

