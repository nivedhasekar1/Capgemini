package com.cap.exception.Employee;


	public class Employee extends Exception
	{
	     /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		public Employee(String Str) 
	        { 
	            super(Str); 
	        } 
	}


