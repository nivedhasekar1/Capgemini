package com.cap;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class CreateEx {
public static void main(String[] args) throws ClassNotFoundException, SQLException {
	
	// 5 + 1 steps
	//step-1 loading the driver class--->oracledriver
	
	Class.forName("oracle.jdbc.driver.OracleDriver");
	
	//step-2 create connection

	Connection conn=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","nivedha","nivi20");
	
	//step-3 create statement
	
	Statement stmt=conn.createStatement();
	
	//step-4 execute query
	
	boolean val=stmt.execute("create table emp9(eid number,ename varchar2(20))");
	System.out.println("table created"+val);
	
	//ddl--execute()---boolean
	//dml--executeUpdate()---int
	//drl--excuteQuery---resultset
	// step-5 close the connection
	
	conn.close();
}
}
