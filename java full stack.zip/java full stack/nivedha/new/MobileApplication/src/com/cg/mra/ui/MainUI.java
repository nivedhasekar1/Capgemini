package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cp.mra.exception.AccountNotFoundException;

public class MainUI {
	
	 static AccountService service =  new AccountServiceImpl();
	 static Scanner scanner = new Scanner(System.in);
	 static Account account;
	 

	    public static void main(String[] args) {

	 

	        while (true) {
	        	System.out.println("*******************");
	        	System.out.println("Mobile Application");
	        	System.out.println("*******************");
	            System.out.println("1.Account Balance Enquiry");
	            System.out.println("2.Recharge Account");
	            System.out.println("3. Exit");
	            System.out.println("Enter your Choce");
	            int option = scanner.nextInt();
	            switch (option) {
	            case 1:
	                try {

	 

	                    System.out.println("Enter MobileNo : ");
	                    String mobileNo = scanner.next();
	                    account = service.getAccountDetails(mobileNo);
	                    System.out.println("Your Current Balance is: Rs." + account.getAccountBalance());
	                } catch (AccountNotFoundException e) {
	                    System.out.println(e.getMessage());
	                }
	                break;
	            case 2:
	                try {
	                    System.out.println("Enter MobileNo : ");
	                    String mobileNo1 = scanner.next();
	                    System.out.println("Enter Recharge Amount : ");
	                    double rechargeAmount = scanner.nextDouble();
	                    int account1 = service.rechargeAccount(mobileNo1, rechargeAmount);
	                    System.out.println("Your Recharge Done Successfully");
	                    System.out.println("Hello " + account.getCustomerName() + " Your Available Balance is "
	                            + account.getAccountBalance());
	                } catch (AccountNotFoundException e) {
	                    System.out.println(e.getMessage());
	                }
	                break;

	 

	            case 3:
	                System.out.println("Thanks for using our Application");
	                System.exit(0);
	            default:
	                break;
	            }
	        }
	    }
	}