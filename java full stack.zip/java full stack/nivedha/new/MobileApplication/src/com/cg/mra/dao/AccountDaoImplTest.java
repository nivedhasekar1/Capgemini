package com.cg.mra.dao;



import org.junit.Assert;
import org.junit.Test;

import com.cg.mra.beans.Account;


public class AccountDaoImplTest {

	AccountDaoImpl dao=new AccountDaoImpl();
	
	@Test
	public void testRechargeAccount() {
		String mobileNo="9823920123";
		Account accountBefore=dao.getAccountDetails(mobileNo);
		System.out.println("account="+accountBefore.getAccountBalance());
		int result=dao.rechargeAccount(mobileNo, 15);
		int expectedResult=468;
	 Assert.assertEquals(expectedResult, result);
	 dao.rechargeAccount(mobileNo, -15);
		
	}

}
