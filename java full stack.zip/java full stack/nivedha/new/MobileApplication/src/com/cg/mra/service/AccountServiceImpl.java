package com.cg.mra.service;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;

public class AccountServiceImpl implements AccountService {
AccountDao dao= new AccountDaoImpl();
	@Override
	public Account getAccountDetails(String mobileNo) {
		return dao.getAccountDetails(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileNo1, double rechargeAmount) {
		// TODO Auto-generated method stub
		return dao.rechargeAccount(mobileNo1, rechargeAmount);
	}

}
