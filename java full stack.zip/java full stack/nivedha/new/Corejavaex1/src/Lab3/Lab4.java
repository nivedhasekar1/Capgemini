package Lab3;

import java.util.Scanner;

public class Lab4 {
	
	
		static int rmd,sum=0;
		static void getcube(int num)
		{
			while(num>0)
			{
				rmd=num%10;
				sum+=(rmd*rmd*rmd);
				num=num/10;
			}
			System.out.println("The sum of the cubes of the digits of an n digit number is: "+sum);
		}
		public static void main(String[] args) {
			System.out.print("Enter the digit:");
			Scanner sc=new Scanner(System.in);
			int num=sc.nextInt();
			Lab4.getcube(num);	
		}

	}

