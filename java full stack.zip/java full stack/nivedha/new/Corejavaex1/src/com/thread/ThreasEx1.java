package com.thread;

class Test1 extends Thread
{
	@Override
	public void run() {
		Thread.currentThread().setName("hello");
		for(int i=0;i<10;i++)
		{
			try {
				Thread.sleep(3000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(Thread.currentThread());
			System.out.println("child thread");
		}
		// TODO Auto-generated method stub
	}
}
public class ThreasEx1 {

public static void main(String[] args)
{
	Thread.currentThread().setPriority(Thread.MIN_PRIORITY);
	Test1 t=new Test1();
	t.start();
	for(int i=0;i<10;i++)
	{
		Thread.currentThread().setName("hi");
		System.out.println(Thread.currentThread().getName());
		System.out.println("parent thread");
	}
}
}
