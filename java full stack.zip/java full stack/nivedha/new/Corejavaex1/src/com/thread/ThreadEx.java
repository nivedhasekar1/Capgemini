package com.thread;
class Test implements Runnable
{

	@Override
	public void run() {
		for(int i=0;i<10;i++)
		{
			System.out.println("child thread");
		}
		// TODO Auto-generated method stub
		
	}
	
}
public class ThreadEx 
{
public static void main(String[] args)
{
	Test t=new Test();
	Thread t1=new Thread(t);
	t1.start();
	for(int i=0;i<10;i++)
	{
		System.out.println("parent thread");
	}
}
}
