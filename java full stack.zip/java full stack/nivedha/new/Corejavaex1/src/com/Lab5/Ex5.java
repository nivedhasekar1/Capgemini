package com.Lab5;

import java.util.Scanner;

class AgeException extends Exception{
	public AgeException(String str){
		System.out.println(str);
	}
}
public class Ex5 {
public static void main(String[] args) {
	Scanner s=new Scanner(System.in);
	System.out.println("enter your age:");
	int age = s.nextInt();
	try{
	if(age<15)
	{
		System.out.println("Invalid age");
	}
	else{
		System.out.println("valid age");
	}}
	catch(Exception a){
		System.out.println(a);
	}

}}
