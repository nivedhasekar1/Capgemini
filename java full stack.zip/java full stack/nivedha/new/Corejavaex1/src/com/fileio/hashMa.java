package com.fileio;

import java.util.*;
import java.util.Map.Entry;

public class hashMa {
	public static void main(String[] args) {
		HashMap<Integer,String> h=new HashMap<Integer,String>();//key-integer ,value-string
		//HashMap h=new HashMap();
		h.put(1, "hi");
		h.put(2, "hello");
		h.put(2, "abc");
		h.put(4, "abc1");
		System.out.println(h);

		Set set=h.entrySet();
      Iterator itr= set.iterator();
     while(itr.hasNext())
     {
    	 Entry entry=(Entry) itr.next();
         System.out.println(entry.getKey());
         System.out.println(entry.getValue());
     // System.out.println(itr.next());
     }	
	}
}
