package com.fileio;
import java.io.*;
public class PrintWr {
	
public static void main(String[] args) throws IOException {
	//FileWriter fw=new FileWriter("abc1.txt");
	PrintWriter out=new PrintWriter("abc1.txt");
	out.println(1000);
	out.println(false);
	out.println('s');
	out.println("ibm");
	out.flush();
	out.close();
//fw.close():
}
}
