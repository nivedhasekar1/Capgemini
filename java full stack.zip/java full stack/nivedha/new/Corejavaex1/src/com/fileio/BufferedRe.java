package com.fileio;
	import java.io.*;
	public class BufferedRe {
		public static void main(String[] args) throws IOException {
			FileReader fr=new FileReader("abc1.txt");
			BufferedReader br=new BufferedReader(fr);
			String line=br.readLine();
			while(line!=null)
			{
				System.out.println(line);
				line=br.readLine();
			}
			br.close();
		}

}
