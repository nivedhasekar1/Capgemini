package com.fileio;

import java.util.IdentityHashMap;

public class IdentityHashMapEx
{
public static void main(String[] args) {
	
	IdentityHashMap i=new IdentityHashMap();
	
	Integer i1=new Integer(10);
	Integer i2=new Integer(10);
	
	i.put(i1, "hi");
	i.put(i2, "hello");
	System.out.println(i);
}
}
