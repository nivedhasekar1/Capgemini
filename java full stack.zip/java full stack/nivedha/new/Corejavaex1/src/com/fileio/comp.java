package com.fileio;

import java.util.Comparator;
import java.util.TreeSet;

public class comp {
	public static void main(String[] args) {
		TreeSet ts=new TreeSet(new MyComparator1());
		
		//for integer
		//ts.add(7);
		//ts.add(1);
		//ts.add(9);
		
		//for string
		ts.add("hi");
		ts.add("welcome");
		ts.add("hello");
		
		System.out.println("set:"+ts);
	}}
class MyComparator1 implements Comparator
{
	//--return +ve if obj1 has to come before obj2
			//--return -ve if obj1 has to come after obj2
			//--return 0 both are equal

	@Override
	public int compare(Object o1, Object o2) {
		
		//for strings
		String i1=o1.toString();
		String i2=o2.toString();
		
		//for integers
		//Integer i1=(Integer) o1;
		//Integer i2=(Integer) o2;
		
		//return -i1.compareTo(i2);//another way for desc order
		
		return i2.compareTo(i1); //both integers and strings
		
		/*if(i1<i2)  //another way for desc order
			return +1;
		else if(i1>i2)
			return -1;
		else
			return 0;*/
	}
}
