package com.fileio;
import java.io.*;

class Emp implements Serializable {
		private int empid;
		private String name;
		transient private int  sal;
		
		public int getEmpid() {
			return empid;
		}
		public void setEmpid(int empid) {
			this.empid = empid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getSal() {
			return sal;
		}
		public void setSal(int sal) {
			this.sal = sal;
		}
		}
	public class Exam4  {
	public static void main(String[] args) throws Exception {
		Emp e=new Emp();
		e.setEmpid(97);
		e.setName("nivedha");
		e.setSal(15000);
		FileOutputStream fos=new FileOutputStream("capg.txt");
		ObjectOutputStream os=new ObjectOutputStream(fos);
		os.writeObject(e);
		System.out.println("success");
	}

}
