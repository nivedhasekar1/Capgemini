package com.fileio;

import java.io.File;
import java.io.IOException;

public class FileEx {
public static void main(String[] args) throws IOException {
	File f=new File("cap1.txt");
	File f1=new File("cap");
	f.createNewFile();
	System.out.println("created");
	System.out.println(f.exists());
	System.out.println(f.createNewFile());
	System.out.println(f.exists());
	System.out.println(f.isDirectory());
	System.out.println(f.isFile());
	System.out.println(f1.mkdir());
	System.out.println(f1.exists());
	System.out.println(f1.isDirectory());
	System.out.println(f1.isFile());
	System.out.println(f1.delete());
	System.out.println(f.setReadOnly());
}
}
