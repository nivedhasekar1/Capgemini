package com.fileio;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class Exam3 {
	    public static void main(String[] args) throws IOException {
	        int flag=0;
	        
	        
	        Scanner in=new Scanner(System.in);
	        System.out.println("Enter username:");
	        String user=in.next();
	        System.out.println("Enter password:");
	        String pass=in.next();
	        
	        
	        
	        FileReader fr=new FileReader("cap1.txt");
	        BufferedReader br=new BufferedReader(fr);
	        try{
	        while(fr!=null)
	        {
	            if(user.equals(br.readLine().toString()) && pass.equals(br.readLine().toString())) 
	            {
	                flag=1;
	                break;
	            }
	        }
	        if(flag==1)
	        {
	            System.out.println("correct");    
	        }
	        }
	        catch(Exception e)
	        {
	            System.out.println("username and password is incorrect");
	        }
	        br.close();
	    }
	}
