package com.fileio;
import java.io.*;
public class BufferedWr {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("abc.txt");
	BufferedWriter bw=new BufferedWriter(fw);
	bw.write(97);
	bw.newLine();
	char [] ch1={'a','b','c','d'};
	bw.write(ch1);
	bw.newLine();
	bw.write("welcome");
	bw.newLine();
	bw.write("to ibm");
	bw.flush();
	bw.close();
	fw.close();
}
}
