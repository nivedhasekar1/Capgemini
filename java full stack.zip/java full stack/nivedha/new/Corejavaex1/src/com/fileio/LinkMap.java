package com.fileio;

import java.util.LinkedHashMap;
import java.util.TreeMap;

public class LinkMap {
	public static void main(String[] args) {
		LinkedHashMap<Integer,String> ht=new LinkedHashMap<Integer,String>();//key-integer ,value-string
		LinkedHashMap h=new LinkedHashMap();
		h.put(1, "hi");
		h.put(2, "hello");
		h.put(2, "abc");
		h.put(4, "abc1");
		System.out.println(h);
		ht.put(1, "xyz");
		ht.put(2, "xyz1");
		ht.put(1, "xyz3");
			
		System.out.println(ht);
		System.out.println(h.get(2));
		System.out.println(h.remove(2));
		System.out.println(h.containsKey(1));
		System.out.println(h.containsValue("abc"));
		System.out.println(h.isEmpty());
		System.out.println(h.size());
		System.out.println(h.keySet());
		System.out.println(h.entrySet());
		
	}

}
