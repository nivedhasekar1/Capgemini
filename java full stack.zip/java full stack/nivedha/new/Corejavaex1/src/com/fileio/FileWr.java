package com.fileio;
import java.io.FileWriter;
import java.io.IOException;

public class FileWr {
public static void main(String[] args) throws IOException {
	FileWriter fw=new FileWriter("cap2.txt");
	fw.write(97);
	fw.write("hi \n hello");
	fw.write("\n");
	char [] ch1={'a','b','c'};
	fw.write(ch1);
	fw.write("\n");
	fw.flush();
	fw.close();
	
}
}
