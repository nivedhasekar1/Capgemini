package com.fileio;
class First{
public synchronized void display(String msg)
{
	System.out.print("[" +msg);
	try {
		Thread.sleep(3000);
	} catch (InterruptedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	System.out.println("]");
}
}
class Second extends Thread{
	String msg;
	First fobj;
	
	Second(First fobj,String msg){
		this.fobj=fobj;
		this.msg=msg;
		this.start();
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		fobj.display(msg);
	}
}
public class Synchro {
	public static void main(String[] args) {
		First fnew=new First();
		Second s=new Second(fnew,"hi");
		Second s1=new Second(fnew,"hello");
		Second s2=new Second(fnew,"java");
	}
}
