package com.fileio;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
public class Exam2 {
public static void main(String[] args) throws IOException {
	Scanner s=new Scanner(System.in);
	
	
	FileReader fr=new FileReader("cap1.txt");
	BufferedReader br=new BufferedReader(fr);
	String i1=br.readLine();
	String a1=br.readLine();
	while(i1!=null && a1!=null)
	{
		System.out.println("enter the username:");
		String i=s.next();
		System.out.println("enter password:");
		String a=s.next();
		if(i.equals(i1) && a.equals(a1)){
	
	
	System.out.println("login successfull");
	}
	else{
		System.out.println("login fails");
	}
	}
		s.close();
	
}
}