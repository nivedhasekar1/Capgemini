package com.bank.dao;



import org.junit.Assert;
import org.junit.Test;

import com.bank.bean.BankAccount;


public class BankDaoImpTest {
BankDaoImp dao=new BankDaoImp();


	@Test
	public void createAcc1() {
		BankAccount bank=new BankAccount();
		bank.setBalance(1500);
        bank.setAccountNo(1000);
        bank.setAccType("saving");
        bank.setMoblieNo(987654321);
        bank.setName("nivedha");
        long AccountNum = dao.insertBankAccount(bank);
        Assert.assertEquals(1000, AccountNum);

	}
	public void createAcc2() {
		BankAccount bank=new BankAccount();
		bank.setBalance(1500);
        bank.setAccountNo(1000);
        bank.setAccType("saving");
        bank.setMoblieNo(987654321);
        bank.setName("nivedha");
        long AccountNum = dao.insertBankAccount(bank);
        Assert.assertEquals(1000, AccountNum);

    }
	
	}


