package com.bank.service;

import java.util.List;

import com.bank.bean.BankAccount;
import com.bank.bean.Transaction;
import com.bank.dao.BankDao;
import com.bank.dao.BankDaoImp;

public class BankServiceImp implements BankService {

	BankDao dao = new BankDaoImp();

	@Override
	//getting users info
	public void insertBankAccount(BankAccount account) {
		
		dao.insertBankAccount(account);

	}

	@Override
	//showing users info
	public BankAccount retrieveBankAccount(long accountNo) {
		
		BankAccount bank1 = dao.retrieveBankAccount(accountNo);
		return bank1;
	}

	@Override
	//for depositing amount in given account no
	public BankAccount depositAmount(long accno2, long depositAmount) {
		
		return dao.depositAmount(accno2, depositAmount);
	}

	@Override
	//for withdrawing amount in given account no
	public BankAccount withdrawAmount(long accno3, long withdrawAmount) {
		
		return dao.withdrawAmount(accno3, withdrawAmount);
	}

	@Override
	//for transfer amount from given accounts
	public BankAccount fundTransfer(long accNo1, long accNo2, long transferAmount) {
		
		return dao.fundTransfer(accNo1, accNo2, transferAmount);
	}

	@Override
	//displaying the transcation details
	public List<Transaction> printTransaction() {
		

		return dao.printTransaction();
	}

	@Override
	//validation for name starts with caps
	public boolean validation(String name) {
	if(name.matches("[A-Z][a-z]*"))
		return true;
	else
		return false;
		
	}

	@Override
	//validation for mobile number
	public boolean mobileValidation(long mobileNo) {
		String num=Long.toString(mobileNo);
		if(num.matches("[6-9][0-9]{9}"))
			return true;
		else
			return false;
	}

}
