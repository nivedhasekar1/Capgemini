package com.bank.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.bank.bean.BankAccount;
import com.bank.bean.Transaction;
import com.bank.exception.AccountNotFoundException;
import com.bank.service.BankService;
import com.bank.service.BankServiceImp;

public class MainUi {

	static BankService service = (BankService) new BankServiceImp();
	static Scanner scanner = new Scanner(System.in);//user input

	public static void main(String[] args) {
		while (true) {
			System.out.println("\n");
			System.out.println("*****************");
			System.out.println("Bank application");
			System.out.println("*****************");
			System.out.println("1.create account");
			System.out.println("2.show Balance");
			System.out.println("3.amount deposit");
			System.out.println("4.withdraw");
			System.out.println("5.fund transfer");
			System.out.println("6.print trancsation");
			System.out.println("7.exit");

			int option = scanner.nextInt();//user input
			switch (option) {
			
			case 1:
				boolean validation=false;
				String name=null;
				
				do{//validation for First letter of the name must be in caps
					System.out.println("Enter Your Name:");
					name=scanner.next();
					validation=service.validation(name);
					if(!validation)
					{
						System.out.println("First letter should be in caps");
						System.out.println("Enter Alphabets only ");
						
					}}
				while(!validation);
				
				System.out.println("Enter Your Branch:");
				String branch = scanner.next();
				System.out.println("Enter Your accType:");
				String accType = scanner.next();
				System.out.println("Enter Your Balance:");
				int balance = scanner.nextInt();
					 
				boolean num1 = false;	
				//validation for mobile number contains 10 digits and start with 6-9
				
				System.out.println("Enter Your MobileNo:");
				long mobileNo;
				do {
                    mobileNo = scanner.nextLong();
                     num1 = service.mobileValidation(mobileNo);
                    if (!num1) {
                        System.out.println("Enter Valid Mobile Number...\n Please Enter 10 Digits Number");
                        System.out.println("Enter Your Mobile Number");
                    }
                } while (!num1);

				long accountNo = mobileNo - 87546;//generate account no

				BankAccount account = new BankAccount();//creating object
				account.setAccountNo(accountNo);
				account.setName(name);
				account.setAccType(accType);
				account.setBalance(balance);
				account.setBranch(branch);
				account.setMoblieNo(mobileNo);
				service.insertBankAccount(account);
				System.out.println("***ACCOUNT CREATED***");

				System.out.println("Your Account Number is:" + accountNo);
				System.out.println("\n");
				System.out.println(account);
				
				break;

			case 2:
				//showing the account info
				try{
				//Handling Exception if the account no is invalid
				System.out.println("Fetching Bank Details");
				System.out.println("Enter Your Account Number:");
				long accNo1 = scanner.nextLong();
				BankAccount bank3 = service.retrieveBankAccount(accNo1);
				System.out.println(bank3);
				System.out.println("Your Balance Is:");
				System.out.println(bank3.getBalance());
				System.out.println("\n");
				}catch(AccountNotFoundException ae){
					System.out.println(ae.getMessage());
					
				}
				break;

			case 3:
				//Handling Exception if the account no is invalid
				try{
				System.out.println("Deposit");
				System.out.println("Enter Your AccountNo:");
				long accNo2 = scanner.nextLong();

				System.out.println("Enter The Amount To Be Deposit:");
				Long depositAmount = scanner.nextLong();
				BankAccount bank2 = service.depositAmount(accNo2, depositAmount);
				System.out.println("***AMOUNT DEPOSIT SUCCESSFULLY***");
				System.out.println("The Current Balance Is:" + bank2.getBalance());
				System.out.println(bank2);
				System.out.println("\n");
				}catch(AccountNotFoundException ae){
					
					System.out.println(ae.getMessage());
				}
				break;

			case 4:
				//Handling Exception if the account no is invalid
				try{
				System.out.println("Withdraw");
				System.out.println("Enter Your AccountNo:");
				long accNo3 = scanner.nextLong();

				System.out.println("Enter The Amount To Be Withdraw:");
				Long withdrawAmount = scanner.nextLong();
				BankAccount bank1 = service.withdrawAmount(accNo3, withdrawAmount);
				System.out.println("***AMOUNT WITHDRAW SUCCESSFULLY***");
				System.out.println("The Current Balance Is:" + bank1.getBalance());
				System.out.println(bank1);
				System.out.println("\n");
				}catch(AccountNotFoundException ae){
				
				System.out.println(ae.getMessage());
				}
				break;

			case 5:
				//Handling Exception if the account no is invalid
				try{
				System.out.println("Enter Your Account Number:");
				Long accNo7 = scanner.nextLong();
				System.out.println("Enter Payee Account number");
				Long accNo6 = scanner.nextLong();
				System.out.println("Enter Tranfer Amount:");
				Long transferAmount = scanner.nextLong();
				BankAccount b5 = service.fundTransfer(accNo6, accNo7, transferAmount);
				System.out.println("***AMOUNT TRANSFER SUCCESSFULLY***");
				System.out.println("Your Current Balance Is " + b5.getBalance());
				}catch(AccountNotFoundException ae){
				
				System.out.println("insuffient balance");
				}
				break;
				
			case 6:
				//displaying all the transcation 

				System.out.println("Showing All The Transaction");
				List<Transaction> result = service.printTransaction();
				Iterator<Transaction> itr = result.iterator();
				while (itr.hasNext()) {
					Transaction banktr = itr.next();
					System.out.println(banktr);

				}
				break;

			case 7:
				System.out.println("***THANK YOU***");
				System.exit(0);

			}
		}
	}
}
