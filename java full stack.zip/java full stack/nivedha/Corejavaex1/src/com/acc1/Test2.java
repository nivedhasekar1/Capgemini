package com.acc1;

import java.util.ArrayList;

public class Test2 {
	public static void main(String[] args)
	{
		ArrayList a1=new ArrayList();
		a1.add("ab");
		a1.add("xx");
		a1.add("cc");
		ArrayList a2=new ArrayList();
		a2.add("ab");
		a2.add("xa");
		a2.add("cc");
		System.out.println(a1);
	 a1.remove(1);
	 a1.contains(a2);
	 System.out.println(a1);
	}}
