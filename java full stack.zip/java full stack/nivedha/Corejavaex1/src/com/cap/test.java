package com.cap;

public class test 
{
	int a=7;
	static int b=3;
	void m1()
	{
		System.out.println("test class instance method");
	}
	static void m2()
	{
		System.out.println("test class static method");
	}
public static void main(String[] args) {
	test t=new test();
	t.m1();
	test.m2();
	System.out.println(t.a);
	System.out.println(b);
	System.out.println("welcome to java");
}
}
