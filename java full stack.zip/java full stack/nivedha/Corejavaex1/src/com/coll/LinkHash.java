package com.coll;

import java.util.HashSet;
import java.util.LinkedHashSet;

public class LinkHash {
public static void main(String[] args) {
	LinkedHashSet h=new LinkedHashSet();
	h.add(37);
	h.add(91);
	h.add("hi");
	h.add(37);
	h.add(91);
	h.add("hi");
	System.out.println(h);
}
}
