package com.coll;

import java.util.LinkedList;

public class LinkedEx {
public static void main(String[] args) {
	LinkedList a1=new LinkedList();
	a1.add(1);
	a1.add(67);
	a1.add("hi");
	a1.addFirst(a1);
	a1.addLast(a1);
	System.out.println(a1);
	System.out.println(a1.getFirst());
	System.out.println(a1.getLast());
	System.out.println(a1.removeFirst());
	System.out.println(a1.removeLast());
}
}

