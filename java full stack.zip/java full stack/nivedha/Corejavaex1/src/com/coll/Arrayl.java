package com.coll;
import java.util.*;
public class Arrayl {
	public static void main(String[] args) {
		
		//ArrayList a1=new ArrayList();
		LinkedList a1=new LinkedList();
		//(current capacity*3/2)+1 array size increase formula
		a1.add(1);
		a1.add(67);
		a1.add("hi");
		a1.add("hi");
		System.out.println(a1);
		a1.remove(3);
		
		//(current capacity*3/2)+1 array size increase formula
		//ArrayList a2=new ArrayList();
		LinkedList a2=new LinkedList();
		a2.add(13);
		a2.add(73);
		a2.add(97);
		a2.add("hello");
		System.out.println(a2);
		a2.add(a1);
		System.out.println(a2);
		a2.addAll(a1);
		System.out.println(a1.contains(1));
		System.out.println(a1.containsAll(a2));
		System.out.println(a1.retainAll(a1));
		
		//ArrayList<integer> a2=new ArrayList<integer>(); for int data type
		
		a2.removeAll(a2);
		System.out.println(a2);
		a2.retainAll(a2);
		System.out.println(a2);
		a2.clear();
		System.out.println(a1);
		System.out.println(a2.containsAll(a1));
		System.out.println(a1.size());
		a1.isEmpty();
		System.out.println(a1);
		System.out.println(a1.isEmpty());
	    System.out.println(a2.toArray());
	 
	}	
	}