package com.coll;

import java.util.Enumeration;
import java.util.Vector;

public class Enu {
public static void main(String[] args) {
	Vector daynames=new Vector();
	daynames.add("sunday");
	daynames.add("monday");
	daynames.add("tuesday");
	daynames.add("wednesday");
	daynames.add("thursday");
	daynames.add("friday");
	daynames.add("saturday");
	System.out.println(daynames);
	Enumeration days=daynames.elements();
	while(days.hasMoreElements())
	{
		System.out.println(days.nextElement());
	}
}
}
