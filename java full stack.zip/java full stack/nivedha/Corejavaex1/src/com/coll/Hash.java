package com.coll;

import java.util.HashSet;

public class Hash {
public static void main(String[] args) {
	HashSet h=new HashSet();
	h.add(37);
	h.add(91);
	h.add("hi");
	h.add(37);
	h.add(91);
	h.add("hi");
	System.out.println(h);
	
}
}
