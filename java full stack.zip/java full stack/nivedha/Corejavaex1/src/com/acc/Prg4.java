package com.acc;

public class Prg4 {
	
	    public static void main(String[] args) {
	        String s1="hi";
	        String s2="hi hello";
	        System.out.println(s1.endsWith(s2));
	    }

	}
