package com.acc;
class A
{
	public void m1()
	{
		System.out.println("public method");
	}
}
public class Test extends A
{
	public  int a=123;
	public static void main(String[] args)
	{
		A c=new A();
		c.m1();
	}
}