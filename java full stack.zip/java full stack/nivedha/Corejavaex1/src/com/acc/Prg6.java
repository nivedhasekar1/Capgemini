package com.acc;

public class Prg6 {
	
	     public static void main(String[] args) {
	           
	           
	          String str= "welcome to java";
	        
	            for (int i = 0; i < str.length(); i++) {
	           
	                    if(Character.isUpperCase(str.charAt(i))){   
	                    System.out.println(str.charAt(i));
	                    }
	                   
	         }
	        
	        }
	        
	       
	}

