package com.cons;

public class Enc {
private int empid;
private String name;
private int  sal;
private int atmpin;
public int getEmpid() {
	return empid;
}
public void setEmpid(int empid) {
	this.empid = empid;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public int getSal() {
	return sal;
}
public void setSal(int sal) {
	this.sal = sal;
}
public int getAtmpin() {
	return atmpin;
}
public void setAtmpin(int atmpin) {
	this.atmpin = atmpin;
}
}
