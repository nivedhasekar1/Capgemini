package com.cons;

public class Exc2 {
	public static void main(String[] args) {
	try{
		int c=12/4;
		try{
			System.out.println("division");
			int b=30/0;
		}catch(ArithmeticException e){
			System.out.println(e);
		}
			try{
				int a[]=new int[3];
				a[3]=4;
			}catch(ArrayIndexOutOfBoundsException ea){
				System.out.println(ea);
			}finally{
				System.out.println("always will execute");
			}
			System.out.println("remaining try statement");
		}
			catch(Exception e){
				System.out.println("handeled");
			}
		System.out.println("normal execution...");	
		}
	}
