package com.cons;

public class Exc1 {
	public static void main(String[] args) {
		try{
			int a1=10;
			int b=0;
			int c=a1/b;
		}catch(Exception e){
			System.out.println("don't enter zero");
			e.printStackTrace();
			System.out.println(e.getMessage());
			System.out.println(e);
		}
		try
		{
			int a[]=new int[5];
			a[0]=1;
			a[3]=6;
		}
			
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("array index maximum size is 4");
		}
		System.out.println("remaining code");
	}

}
