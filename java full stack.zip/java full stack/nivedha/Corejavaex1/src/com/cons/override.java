package com.cons;

public @interface override {

}
