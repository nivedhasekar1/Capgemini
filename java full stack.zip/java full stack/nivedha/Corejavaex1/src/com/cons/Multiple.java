package com.cons;
class G
{
	void m1()
	{
		System.out.println("class g");
	}
}
class H extends G 
{
	void m2()
	{
		System.out.println("class h");
	}
}
class J extends H
{
	void m2()
	{
		System.out.println("class j");
	}
}
class K extends J
{
	void m3()
	{
		System.out.println("class k");
	}
}
public class Multiple extends K {
	public static void main(String[] args) {
		System.out.println("multiple");
		Multiple m=new Multiple();
		m.m1();
		m.m2();
		m.m3();
	}

}