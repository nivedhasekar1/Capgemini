package com.cons;
class C
{
	void m1()
	{
		System.out.println("class a");
	}
	void m2()
	{
		System.out.println("class b");
	}
}
class B extends C
{
	void m3()
	{
		System.out.println("class c");
	}
	void m4()
	{
		System.out.println("class d");
	}
}
public class Inh extends B
{
	public static void main(String[] args) {
		System.out.println("multilevel");
		Inh i=new Inh();
		i.m1();
		i.m2();
		i.m3();
		i.m4();
		
	}

}
