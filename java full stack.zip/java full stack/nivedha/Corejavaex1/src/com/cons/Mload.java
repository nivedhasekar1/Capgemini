package com.cons;

class Sam{
	static void add(){
		System.out.println("defalut value");
	}
	static void add(int a,int b){
		System.out.println("add:"+(a+b));
	}
	static void add(float a,float b){
		System.out.println("add:"+(a+b));
	}
	static void add(int a,float b){
		System.out.println("add:"+(a+b));
	}
	static void add(float a,int b){
		System.out.println("add:"+(a+b));
	}

}
 class Mload 
{
	public static void main(String[] args) {
		Sam.add();
		Sam.add(3,7);
	    Sam.add(1.7f,3.9f);
		Sam.add(3.3f,7);
		Sam.add(7.1f,5);
		}
}