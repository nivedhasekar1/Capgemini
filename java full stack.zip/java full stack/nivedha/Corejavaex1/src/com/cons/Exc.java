package com.cons;
import java.util.Scanner;
public class Exc {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		System.out.println("enter 1st no:");
		int f=s.nextInt();
		System.out.println("enter 2st no:");
		int t=s.nextInt();
		try{
		int d=f/t;
		System.out.println("division:"+d);
		}catch(Exception e)
		{
			System.out.println("don't enter zero");
		}finally{
		System.out.println("remaining code");
		}
		s.close();
	}

}
