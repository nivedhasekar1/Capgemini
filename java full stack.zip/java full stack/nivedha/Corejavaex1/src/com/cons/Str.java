package com.cons;
public class Str {
	
	public static void main(String[] args) {
		String s1="hi";
		String s2="   Hi hello   ";
		String s3=new String("hello");
		System.out.println(s1.equals(s3));
		System.out.println(s1==s3);
		System.out.println(s1.equals(s2));
		System.out.println(s1.equalsIgnoreCase(s2));
		System.out.println(s1==s2);
		String s4="helLo";
		String s5="hallo";
		System.out.println(s4.compareTo(s5));
		System.out.println("as".equals("as"));
		System.out.println(s1.concat(s2));
		System.out.println(s4.replaceFirst(s1, s4));
		System.out.println(s2.toLowerCase());
		System.out.println(s2.toString());
		System.out.println(s2.toUpperCase());
		System.out.println(s3.replaceAll("hello", "welcome"));
		System.out.println(s5.codePointAt(3));
		System.out.println(s4.codePointBefore(1));
		System.out.println(s2.indexOf(s4));
		System.out.println(s3.contentEquals(s2));
		System.out.println(s2.trim());
		System.out.println(s2.compareTo(s4));
		System.out.println(s3.hashCode());
		System.out.println(s4.length());
		
	}}
