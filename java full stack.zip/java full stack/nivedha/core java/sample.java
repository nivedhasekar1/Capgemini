class sample //instance and static difference
{
int var1=321;//instance variable
static int var2=7893;//static variable
void m1()
{
System.out.println("instance method of welcome class");
}
static void m2()
{
System.out.println("static method of welcome class");
}
public static void main(String args[])
{
sample.m2();
sample sam=new sample();
sam.m1();
System.out.println(sam.var1);
System.out.println(sample.var2);
}}