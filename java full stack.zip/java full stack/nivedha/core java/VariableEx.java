class VariableEx
{
static int x=30;
static int y=70;
static void add()
{
int a=137;
int b=179;
int c=a+b;
System.out.println("add of two no"+c);
System.out.println("add of two no"+(x+b));
}
static void sub()
{
int a=137;
int b=179;
int c=a-b;
System.out.println("sub of two no"+c);
System.out.println("sub of two no"+(x-b));
}
static int sub1(int a,int b)
{
return a-b;
}
public static void main(String args[])
{
VariableEx.add();//default method calling
System.out.println(VariableEx.sub1(30,10));//param-method
int sub=VariableEx.sub1(90,70);//param-method
int val=sub+100;
System.out.println("sub");
System.out.println("val");
VariableEx.sub();
System.out.println("welcome");
}}
