package com.cap.test;

public class Add {
	
		public int sum(int a,int b){
		System.out.println("sum is"+a+" "+b+"is:");
		return a+b;
	}

}
