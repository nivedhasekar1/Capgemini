package com.cap.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestEx {
	Add t=new Add();
	
	int i=t.sum(1000,30);
	int j=1030;

	@Test
	public void test() {
		System.out.println("sum is:"+i+"="+j);
		assertEquals(i, j);
		
	}

}
