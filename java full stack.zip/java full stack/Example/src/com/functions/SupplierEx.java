package com.functions;

import java.sql.Date;
import java.util.function.Supplier;

public class SupplierEx {
public static void main(String[] args) {
	Supplier<Date> sup=()->new Date(0);
	System.out.println(sup.get());
}
}
