package com.functions;


import java.util.function.LongToDoubleFunction;

public class Ex7 {
	public static void main(String[] args) {
		LongToDoubleFunction funcn1=i->i*i;
		LongToDoubleFunction funcn2=i->i*i*i;
	       
	        System.out.println("Square of 3 : "+funcn1.applyAsDouble(3));
	        System.out.println("Cube of 3 : "+funcn2.applyAsDouble(7));
	}

}
