package com.functions;


import java.util.function.IntToLongFunction;

public class Ex3 {
	public static void main(String[] args) {
		
        IntToLongFunction funcn1=i->i*i;//here the parameters is not not working
        IntToLongFunction funcn2=i->i*i*i;
        System.out.println("Square of 2 : "+funcn1.applyAsLong(2));//The given data type is Integer but its return type is Double
        System.out.println("Cube of 2 : "+funcn2.applyAsLong(2));
        System.out.println("Square of 3 : "+funcn1.applyAsLong(3));
        System.out.println("Cube of 3 : "+funcn2.applyAsLong(3));
    }
}
