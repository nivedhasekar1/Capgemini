package com.functions;


import java.util.function.DoubleToLongFunction;

public class Ex5 {
	public static void main(String[] args) {
        DoubleToLongFunction df = (x)->{return(int)x+2;};
        System.out.println(df.applyAsLong(7.9));

}}
