package com.functions;

import java.util.function.Consumer;

public class ConsumerEx {
public static void main(String[] args) {
	//parameter can be anything and return void
	Consumer<String> con=i->System.out.println(i+ "hi");
	con.accept("welcome to capgemini ");
	con.accept("welcome ");
}
}
