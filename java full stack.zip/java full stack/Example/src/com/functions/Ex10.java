package com.functions;

import java.util.function.ToDoubleFunction;

public class Ex10 {
	public static void main(String[] args) {
		ToDoubleFunction funcn1=i->2*3;
		ToDoubleFunction funcn2=i->7.1*9.3;
	       
	        System.out.println("Square of 3 : "+funcn1.applyAsDouble(0));
	        System.out.println("Cube of 3 : "+funcn2.applyAsDouble(7));
	}
}
