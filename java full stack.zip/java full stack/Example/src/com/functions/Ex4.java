package com.functions;

import java.util.function.DoubleToIntFunction;

public class Ex4 {
	public static void main(String[] args) {
        DoubleToIntFunction df = (x)->{return(int)x+2;};
        System.out.println(df.applyAsInt(7.9));
    }
}
