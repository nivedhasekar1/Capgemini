package com.functions;


import java.util.function.ToIntFunction;

public class Ex8 {
	public static void main(String[] args) {
		@SuppressWarnings("rawtypes")
		ToIntFunction funcn1=i->8*3;
		ToIntFunction funcn2=i->9+7;
	       
	        System.out.println("Square of 3 : "+funcn1.applyAsInt(3.9));
	        System.out.println("Cube of 3 : "+funcn2.applyAsInt(7.9));
	}

}
