package com.functions;


import java.util.function.LongToIntFunction;

public class Ex6 {
	public static void main(String[] args) {
        LongToIntFunction df = (x)->{return(int)x+2;};
        System.out.println(df.applyAsInt(987785435));
}}
