package com.functions;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

public class LambaWithColl {
	public static void main(String[] args) {
		ArrayList<Integer> a1=new ArrayList<Integer>();
		a1.add(30);
		a1.add(76);
		a1.add(45);
		a1.add(73);
		a1.add(30);
		System.out.println(a1);
		List<Integer> l=a1.stream().filter(i->i%2==0).collect(Collectors.toList());
		System.out.println("filter to print even values:"+l);
		
		List<Integer> l1=a1.stream().map(i->i*2).collect(Collectors.toList());
		System.out.println("map to print double values:"+l1);
		
		long cn=a1.stream().count();
		System.out.println("it will count no of element:" +cn);
		
		List<Integer> l2=a1.stream().sorted((i1,i2)->(i1<i2) ? 1:(i1>i2) ? -1:0).collect(Collectors.toList());
		System.out.println("display in descending order:" +13);
		Integer minVal=a1.stream().min((i1, i2) -> -i1.compareTo(i2)).get();
		System.out.println("minimum value is:" + minVal);
		Integer maxVal=a1.stream().max((i1, i2) -> i2.compareTo(i1)).get();
		System.out.println("maximum value is:" + maxVal);
		
		a1.stream().forEach(i->{System.out.println("the element are:"+i);});
		
		
		
		
	}

}
