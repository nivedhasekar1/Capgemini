package com.functions;


import java.util.function.ToLongFunction;

public class Ex9 {
	public static void main(String[] args) {
		ToLongFunction funcn1=i->2*3;
		ToLongFunction funcn2=i->7*9;
	       
	        System.out.println("Square of 3 : "+funcn1.applyAsLong(3));
	        System.out.println("Cube of 3 : "+funcn2.applyAsLong(7));
	}
}
