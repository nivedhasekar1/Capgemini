import java.util.function.Predicate;



public class StringEx {
	public static void main(String[] args) {
		String [] values= {"hi","hello","welcome"};
		Predicate<String> pre=i->i.length()>=5;
		for(String val:values){
			if(pre.test(val)){
				System.out.println(val);
			}
		}
	}}
