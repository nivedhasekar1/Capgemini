package cap.emp;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;
import java.util.Set;

public class Main {
				 
public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("enter employee name:");
	String empName=sc.next();
	System.out.println("enter employee id:");
	String empId=sc.next();
	
	HashMap<String,Integer> emp=new HashMap<String,Integer>();
	emp.put("a123", 15000);
	emp.put("a234", 21000);
	Set s=emp.entrySet();
	Iterator itr=s.iterator();
	while(itr.hasNext())
	{
		Entry entry=(Entry) itr.next();
		
		System.out.println(entry.getKey());
	}	
}
}
