package cap.emp;

public class Emp {
	private int empid;
	private String empName;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(int empSalary) {
		this.empSalary = empSalary;
	}
	@Override
	public String toString() {
		return "Emp [empid=" + empid + ", empName=" + empName + ", empSalary=" + empSalary + "]";
	}
	private int empSalary;
}
