package com.cap.doa;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cap.entities.Employee;

@Repository
public interface EmpDao extends JpaRepository<Employee, Integer> {

}
