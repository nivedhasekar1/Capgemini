package com.cap.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cap.doa.EmpDao;
import com.cap.entities.Employee;

@Service
public class EmpServiceImpl implements EmpService{
@Autowired
EmpDao empDao;

@Override
public List<Employee> createEmp(Employee emp) {
	empDao.save(emp);
	
	return empDao.findAll();
}

@Override
public Employee updateEmployee(int eid, int amt) {
	  Optional<Employee> emp=empDao.findById(eid);
      Employee tempemp;
      if(emp.isPresent())
      {
          tempemp=emp.get();
          tempemp.setEsal(emp.get().getEsal()+amt);
          empDao.save(tempemp);
      }
      return empDao.findById(eid).get();
  }
}