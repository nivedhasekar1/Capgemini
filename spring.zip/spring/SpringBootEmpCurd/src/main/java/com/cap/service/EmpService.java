package com.cap.service;

import java.util.List;

import com.cap.entities.Employee;

public interface EmpService {
List<Employee> createEmp(Employee emp);
public Employee updateEmployee(int eid, int amt);
}
