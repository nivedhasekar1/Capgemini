package com.cap.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cap.entities.Employee;
import com.cap.service.EmpService;

@RestController
@RequestMapping("/Bank")
public class EmpRestController {
@Autowired
EmpService empService;
@PostMapping("/createaccount")
public List<Employee> createAccount(@RequestBody Employee emp){
	return empService.createEmp(emp);
	
}
@PutMapping("/update/{eid}/{amt}")
public ResponseEntity<Employee> updateEmployee(@PathVariable int eid,@PathVariable int amt)

{
    Employee i= empService.updateEmployee(eid,amt);
    return new ResponseEntity<Employee>(i,HttpStatus.OK);
   
}
}
