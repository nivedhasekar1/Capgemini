package com.cg.respository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.entities.Stock;

public interface StockRepo  extends JpaRepository<Stock, Integer> {

}
