package com.cg.exception;

@SuppressWarnings("serial")
public class StockIdNotFoundException extends Exception {
	public StockIdNotFoundException() {
		super();
	}

	public StockIdNotFoundException(String msg) {
		super(msg);
	}
}
