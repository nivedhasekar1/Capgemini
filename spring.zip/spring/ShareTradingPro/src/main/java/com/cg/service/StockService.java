package com.cg.service;

import java.util.List;

import com.cg.entities.Stock;
import com.cg.exception.StockIdNotFoundException;

public interface StockService {

	List<Stock> viewAllStock() throws StockIdNotFoundException;

	Stock findSingleStock(int id) throws StockIdNotFoundException;

	void deleteStock(int id) throws StockIdNotFoundException;

	List<Stock> createStock(Stock stock) throws StockIdNotFoundException;

	List<Stock> updateStock(int id, Stock stock) throws StockIdNotFoundException;

	int calculateOrder(Stock stock);

}

