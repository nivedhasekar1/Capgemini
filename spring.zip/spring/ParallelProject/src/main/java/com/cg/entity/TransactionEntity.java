package com.cg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="transaction101")
public class TransactionEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO, generator = "b")
	@Column(length = 20)
	private Integer transNo;
	@Column(length = 20)
	private Long accno;
	@Column(length = 20)
	private String transType;
	@Column(length = 20)
	private Double previousBal;
	@Column(length = 20)
	private Double currentBal;
	
	public Integer getTransNo() {
		return transNo;
	}
	public void setTransNo(Integer transNo) {
		this.transNo = transNo;
	}
	public Long getAccno() {
		return accno;
	}
	public void setAccno(Long accno) {
		this.accno = accno;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public Double getPreviousBal() {
		return previousBal;
	}
	public void setPreviousBal(Double previousBal) {
		this.previousBal = previousBal;
	}
	public Double getCurrentBal() {
		return currentBal;
	}
	public void setCurrentBal(Double currentBal) {
		this.currentBal = currentBal;
	}
	@Override
	public String toString() {
		return "TransactionEntity [transNo=" + transNo + ", accno=" + accno + ", transType=" + transType
				+ ", previousBal=" + previousBal + ", currentBal=" + currentBal + "]";
	}
	public TransactionEntity() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TransactionEntity(/*Integer transNo,*/ Long accno, String transType, Double previousBal, Double currentBal) {
		super();
		/*this.transNo = transNo;*/
		this.accno = accno;
		this.transType = transType;
		this.previousBal = previousBal;
		this.currentBal = currentBal;
	}


}
