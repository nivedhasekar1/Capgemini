package com.testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = "C:\\Users\\nivsekar\\Desktop\\testing\\RegisterJobsWorld\\src\\test\\resource\\feature\\Registration.feature",
       glue= {"test.java.stepDefinations"},
    		   dryRun=false,
    			strict = true,
    			monochrome=true,
    			 format = {"pretty" , "html:test-output"}
       )
public class TestRunner {

}
