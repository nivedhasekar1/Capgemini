package stepDefinations;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import elementLocators.ElementLocator;
import pageFactory.PageFactory;


public class StepDefination {
	
	 WebDriver driver;
	 PageFactory PageFactory; 

	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\nivsekar\\Desktop\\chorme\\chromedriver.exe" );
		
		driver= new ChromeDriver();
	}
	
	
	@Given("^Open the Browser$")
	public void open_the_Browser() throws Throwable {
		PageFactory.openbrowser();
	}

	@Given("^Open the Registeration Form$")
	public void open_the_Registeration_Form() throws Throwable {
		PageFactory.linkOpenLogin("C:\\Users\\nivsekar\\Desktop\\WebPages Set A\\RegistrationForm.html");
	}

	@When("^user validate the form Title$")
	public void user_validate_the_form_Title() throws Throwable {
		//pageFactory.PageFactory.verifyTitle();	    
	}

	@When("^Enter the user Id$")
	public void enter_the_user_Id() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.insertKeys(ElementLocator.userId, "2345671");
	}

	@When("^Enter the Password$")
	public void enter_the_Password() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.insertKeys(ElementLocator.password, "capg1234");	
	}

	@When("^Enter the user Name$")
	public void enter_the_user_Name() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		PageFactory.alertHandler();
		Thread.sleep(3000);
		PageFactory.insertKeys(ElementLocator.Name, "capgemini");
	}

	@When("^Enter the user address$")
	public void enter_the_user_address() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		PageFactory.alertHandler();
		Thread.sleep(3000);
		PageFactory.insertKeys(ElementLocator.address, "siruseri,Chennai");
	}

	@When("^select the Country$")
	public void select_the_Country() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(2000);
		PageFactory.alertHandler();
		Thread.sleep(3000);
		PageFactory.select(ElementLocator.country);	
	}

	@When("^Enter the Zip Code$")
	public void enter_the_Zip_Code() throws Throwable {
		PageFactory.insertKeys(ElementLocator.zip, "hdgfhd343");
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.clearBox(ElementLocator.zip);
		PageFactory.insertKeys(ElementLocator.zip, "620055");		 
	}

	
	@When("^Enter the Email Id$")
	public void enter_the_Email_Id() throws Throwable{
		PageFactory.insertKeys(ElementLocator.email,"abcdhdgfifd");
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.clearBox(ElementLocator.email);
		PageFactory.insertKeys(ElementLocator.email,"abcdefrgd@gmail.com");	
	}

	@When("^Select the Sex$")
	public void select_the_Sex() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.clickMethod(ElementLocator.sex);	
	}

	@When("^Select the Language$")
	public void select_the_Language() throws Throwable {
		PageFactory.clickMethod(ElementLocator.submit);
		Thread.sleep(1000);
		PageFactory.alertHandler();
		Thread.sleep(1000);
		PageFactory.clickMethod(ElementLocator.language);	
	}

	@Then("^Click on Submit button$")
	public void click_on_Submit_button() throws Throwable {
		Thread.sleep(1000);
		PageFactory.clickMethod(ElementLocator.submit);	
	}

	@Then("^close the browser$")
	public void close_the_browser() throws Throwable {
		Thread.sleep(1000);
		PageFactory.closeBrowser();
	}


}
