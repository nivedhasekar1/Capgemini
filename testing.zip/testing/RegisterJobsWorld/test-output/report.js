$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nivsekar/Desktop/testing/RegisterJobsWorld/src/test/resource/feature/Registration.feature");
formatter.feature({
  "line": 1,
  "name": "Testing for registration Form",
  "description": "",
  "id": "testing-for-registration-form",
  "keyword": "Feature"
});
formatter.scenario({
  "line": 3,
  "name": "Checking titile",
  "description": "",
  "id": "testing-for-registration-form;checking-titile",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters the html page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid UserId",
  "description": "",
  "id": "testing-for-registration-form;invalid-userid",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters Invalid id",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "displays \u0027User Id should not be empty / length be between 5 to 12\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Password Field",
  "description": "",
  "id": "testing-for-registration-form;invalid-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user enters invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Password should not be empty / length be between 7 to 12\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 19,
  "name": "Invalid Name",
  "description": "",
  "id": "testing-for-registration-form;invalid-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 20,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 21,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 22,
  "name": "display \u0027Name should not be empty and must have alphabet characters only\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 24,
  "name": "Invalid address",
  "description": "",
  "id": "testing-for-registration-form;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 25,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 26,
  "name": "user enters invalid address",
  "keyword": "When "
});
formatter.step({
  "line": 27,
  "name": "display \u0027User address must have alphanumeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 29,
  "name": "Invalid country",
  "description": "",
  "id": "testing-for-registration-form;invalid-country",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 30,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 31,
  "name": "user enters invalid country",
  "keyword": "When "
});
formatter.step({
  "line": 32,
  "name": "display \u0027Select your country from the list\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 34,
  "name": "Invalid Zip code",
  "description": "",
  "id": "testing-for-registration-form;invalid-zip-code",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 35,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 36,
  "name": "user enters invalid zip code",
  "keyword": "When "
});
formatter.step({
  "line": 37,
  "name": "display \u0027ZIP code must have numeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 39,
  "name": "Invalid Email",
  "description": "",
  "id": "testing-for-registration-form;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 40,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 41,
  "name": "user enters invalid ename",
  "keyword": "When "
});
formatter.step({
  "line": 42,
  "name": "displays \u0027You have entered an invalid email address!\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 44,
  "name": "Invalid gender",
  "description": "",
  "id": "testing-for-registration-form;invalid-gender",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 45,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 46,
  "name": "user doesnot select gender",
  "keyword": "When "
});
formatter.step({
  "line": 47,
  "name": "displays \u0027Please Select gender\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.scenario({
  "line": 49,
  "name": "Valid Registration details",
  "description": "",
  "id": "testing-for-registration-form;valid-registration-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "user enters valid  registration details",
  "keyword": "When "
});
formatter.step({
  "line": 52,
  "name": "displays \u0027Registartion completed\u0027",
  "keyword": "Then "
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
formatter.match({});
formatter.result({
  "status": "undefined"
});
});