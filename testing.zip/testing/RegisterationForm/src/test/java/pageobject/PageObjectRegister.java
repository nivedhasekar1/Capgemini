package pageobject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageObjectRegister {
	WebDriver driver;
	@FindBy(name="userid")
	@CacheLookup
	WebElement userid;
	
	@FindBy(name="passid")
	@CacheLookup
	WebElement passid;
	
	@FindBy(name="username")
	@CacheLookup
	WebElement username;
	
	@FindBy(name="address")
	@CacheLookup
	WebElement address;
	
	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	
	@FindBy(name="zip")
	@CacheLookup
	WebElement zip;

	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	
	@FindBy(name="sex")
	@CacheLookup
	WebElement sex;
	
	@FindBy(name="en")
	@CacheLookup
	WebElement en;
	
	@FindBy(name="desc")
	@CacheLookup
	WebElement desc;
	
	public PageObjectRegister(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserid() {
		return userid;
	}

	public void setUserid(WebElement userid) {
		this.userid = userid;
	}

	public WebElement getPassid() {
		return passid;
	}

	public void setPassid(WebElement passid) {
		this.passid = passid;
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(WebElement username) {
		this.username = username;
	}

	public WebElement getAddress() {
		return address;
	}

	public void setAddress(WebElement address) {
		this.address = address;
	}

	public WebElement getCountry() {
		return country;
	}

	public void setCountry(WebElement country) {
		this.country = country;
	}

	public WebElement getZip() {
		return zip;
	}

	public void setZip(WebElement zip) {
		this.zip = zip;
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(WebElement email) {
		this.email = email;
	}

	public WebElement getSex() {
		return sex;
	}

	public void setSex(WebElement sex) {
		this.sex = sex;
	}

	public WebElement getEn() {
		return en;
	}

	public void setEn(WebElement en) {
		this.en = en;
	}

	public WebElement getDesc() {
		return desc;
	}

	public void setDesc(WebElement desc) {
		this.desc = desc;
	}
	
}
