package registeration;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nivsekar\\Desktop\\testing\\RegisterationForm\\src\\test\\resource\\feature\\registration.feature"},
		glue= {"registeration"},
		dryRun=false,
		strict = true,
		monochrome=true,
		 format = {"pretty" , "html:test-output"}
		)
public class TestRunnerRegister {

}
