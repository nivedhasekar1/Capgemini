package registeration;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageobject.PageObjectRegister;

public class StepDefinationRegister {
	
	@Given("^user is on Registartion Form$")
	public void user_is_on_Registartion_Form() throws Throwable {
	    
	}

	@When("^user enters the html page$")
	public void user_enters_the_html_page() throws Throwable {
	    
	}

	@Then("^displays 'Welcome to JobsWorld'$")
	public void displays_Welcome_to_JobsWorld() throws Throwable {
	   
	}

	@When("^user enters Invalid id$")
	public void user_enters_Invalid_id() throws Throwable {
	    
	}

	@Then("^displays 'User Id should not be empty / length be between (\\d+) to (\\d+)'$")
	public void displays_User_Id_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	   
	}

	@When("^user enters invalid password$")
	public void user_enters_invalid_password() throws Throwable {
	   
	}

	@Then("^display 'Password should not be empty / length be between (\\d+) to (\\d+)'$")
	public void display_Password_should_not_be_empty_length_be_between_to(int arg1, int arg2) throws Throwable {
	   
	}

	@When("^user enters invalid name$")
	public void user_enters_invalid_name() throws Throwable {
	   
	}

	@Then("^display 'Name should not be empty and must have alphabet characters only'$")
	public void display_Name_should_not_be_empty_and_must_have_alphabet_characters_only() throws Throwable {
	    
	}

	@When("^user enters invalid address$")
	public void user_enters_invalid_address() throws Throwable {
	    
	}

	@Then("^display 'User address must have alphanumeric characters only'$")
	public void display_User_address_must_have_alphanumeric_characters_only() throws Throwable {
	   
	}

	@When("^user enters invalid country$")
	public void user_enters_invalid_country() throws Throwable {
	    
	}

	@Then("^display 'Select your country from the list'$")
	public void display_Select_your_country_from_the_list() throws Throwable {
	   
	}

	@When("^user enters invalid zip code$")
	public void user_enters_invalid_zip_code() throws Throwable {
	   
	}

	@Then("^display 'ZIP code must have numeric characters only'$")
	public void display_ZIP_code_must_have_numeric_characters_only() throws Throwable {
	  
	}

	@When("^user enters invalid ename$")
	public void user_enters_invalid_ename() throws Throwable {
	 
	}

	@Then("^displays 'You have entered an invalid email address!'$")
	public void displays_You_have_entered_an_invalid_email_address() throws Throwable {
	   
	}

	@When("^user doesnot select gender$")
	public void user_doesnot_select_gender() throws Throwable {
	   
	}

	@Then("^displays 'Please Select gender'$")
	public void displays_Please_Select_gender() throws Throwable {
	  
	}

	@When("^user enters valid  registration details$")
	public void user_enters_valid_registration_details() throws Throwable {
		
	}

	@Then("^displays 'Registartion completed'$")
	public void displays_Registartion_completed() throws Throwable {
	    
	}


}
