$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nivsekar/Desktop/testing/CookingSchool/src/test/resource/Feature/OnlineCookingFeatures.feature");
formatter.feature({
  "line": 1,
  "name": "Validting for Recipe_class_registration  Form",
  "description": "",
  "id": "validting-for-recipe-class-registration--form",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2230522600,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Checking title",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;checking-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters into html page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "ensure the html pauses for 10sec",
  "keyword": "Then "
});
formatter.step({
  "line": 7,
  "name": "check the title \u0027Online Cooking Class Enquiry Form\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 8,
  "name": "verify the text \u0027Online Cooking School\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 264375500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_into_html_page()"
});
formatter.result({
  "duration": 1000200900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 27
    }
  ],
  "location": "StepDefinitionOnline.ensure_the_html_pauses_for_sec(int)"
});
formatter.result({
  "duration": 1001467500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.check_the_title_Online_Cooking_Class_Enquiry_Form()"
});
formatter.result({
  "duration": 26467700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_text_Online_Cooking_School()"
});
formatter.result({
  "duration": 36601200,
  "error_message": "java.lang.AssertionError: expected:\u003cOnline Cooking School\u003e but was:\u003c[[ChromeDriver: chrome on XP (2dcd5cbfcc6b8b05e349a5a9cbfa31c3)] -\u003e xpath: //span[@class\u003d\u0027auto-style4\u0027]]\u003e\r\n\tat org.junit.Assert.fail(Assert.java:88)\r\n\tat org.junit.Assert.failNotEquals(Assert.java:834)\r\n\tat org.junit.Assert.assertEquals(Assert.java:118)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat testrunner.StepDefinitionOnline.verify_the_text_Online_Cooking_School(StepDefinitionOnline.java:61)\r\n\tat ✽.Then verify the text \u0027Online Cooking School\u0027(C:/Users/nivsekar/Desktop/testing/CookingSchool/src/test/resource/Feature/OnlineCookingFeatures.feature:8)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 739176600,
  "status": "passed"
});
formatter.before({
  "duration": 1334083700,
  "status": "passed"
});
formatter.scenario({
  "line": 10,
  "name": "Checking hyperlink",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;checking-hyperlink",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 11,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 12,
  "name": "click the hyperlink \u0027Download our Recipe class Brochure\u0027",
  "keyword": "When "
});
formatter.step({
  "line": 13,
  "name": "ensure the html pauses for 15sec",
  "keyword": "Then "
});
formatter.step({
  "line": 14,
  "name": "verify the text \u0027Recipe class Brochure is sent to your registered mail id\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 15,
  "name": "verify the hyperlink \u0027Go Back to Registration\u0027 is navigated to html page",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 205845200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.click_the_hyperlink_Download_our_Recipe_class_Brochure()"
});
formatter.result({
  "duration": 1200053200,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "15",
      "offset": 27
    }
  ],
  "location": "StepDefinitionOnline.ensure_the_html_pauses_for_sec(int)"
});
formatter.result({
  "duration": 1000149700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_text_Recipe_class_Brochure_is_sent_to_your_registered_mail_id()"
});
formatter.result({
  "duration": 15039955900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_hyperlink_Go_Back_to_Registration_is_navigated_to_html_page()"
});
formatter.result({
  "duration": 2145391900,
  "status": "passed"
});
formatter.after({
  "duration": 821356100,
  "status": "passed"
});
formatter.before({
  "duration": 1265925500,
  "status": "passed"
});
formatter.scenario({
  "line": 17,
  "name": "Enter First Name",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;enter-first-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 18,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 19,
  "name": "user enters Enter first name",
  "keyword": "When "
});
formatter.step({
  "line": 20,
  "name": "display \u0027First Name must be filled out\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 154958900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_Enter_first_name()"
});
formatter.result({
  "duration": 1200193500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.display_First_Name_must_be_filled_out()"
});
formatter.result({
  "duration": 1015523000,
  "status": "passed"
});
formatter.after({
  "duration": 793362000,
  "status": "passed"
});
formatter.before({
  "duration": 1255993900,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Enter Last Name",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;enter-last-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 23,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 24,
  "name": "user enters Enter Last name",
  "keyword": "When "
});
formatter.step({
  "line": 25,
  "name": "display \u0027Last Name must be filled out\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 157900000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_Enter_Last_name()"
});
formatter.result({
  "duration": 1214496400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.display_Last_Name_must_be_filled_out()"
});
formatter.result({
  "duration": 1013330000,
  "status": "passed"
});
formatter.after({
  "duration": 718271900,
  "status": "passed"
});
formatter.before({
  "duration": 1285905400,
  "status": "passed"
});
formatter.scenario({
  "line": 27,
  "name": "Enter Email",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;enter-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 28,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 29,
  "name": "user enters Email",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 135737700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_Email()"
});
formatter.result({
  "duration": 1403880900,
  "status": "passed"
});
formatter.after({
  "duration": 751559600,
  "status": "passed"
});
formatter.before({
  "duration": 1479488800,
  "status": "passed"
});
formatter.scenario({
  "line": 31,
  "name": "Enter mobile",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;enter-mobile",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 32,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 33,
  "name": "user enters Enter mobile",
  "keyword": "When "
});
formatter.step({
  "line": 34,
  "name": "display \u0027Enter numeric value\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 155426800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_Enter_mobile()"
});
formatter.result({
  "duration": 1417273900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.display_Enter_numeric_value()"
});
formatter.result({
  "duration": 1012950900,
  "status": "passed"
});
formatter.after({
  "duration": 731267100,
  "status": "passed"
});
formatter.before({
  "duration": 1352752400,
  "status": "passed"
});
formatter.scenario({
  "line": 36,
  "name": "Invalid mobileNumber",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;invalid-mobilenumber",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 37,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 38,
  "name": "user enters invalid mobile number less than or greater than 10",
  "keyword": "When "
});
formatter.step({
  "line": 39,
  "name": "display \u0027Enter 10 digit Mobile Number\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 166447100,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 60
    }
  ],
  "location": "StepDefinitionOnline.user_enters_invalid_mobile_number_less_than_or_greater_than(int)"
});
formatter.result({
  "duration": 1433218500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "10",
      "offset": 15
    }
  ],
  "location": "StepDefinitionOnline.display_Enter_digit_Mobile_Number(int)"
});
formatter.result({
  "duration": 1016326300,
  "status": "passed"
});
formatter.after({
  "duration": 922389300,
  "status": "passed"
});
formatter.before({
  "duration": 1273056600,
  "status": "passed"
});
formatter.scenario({
  "line": 41,
  "name": "select Category",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;select-category",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 42,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 43,
  "name": "user enters category as \u0027Non-Veg\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 173201800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_category_as_Non_Veg()"
});
formatter.result({
  "duration": 1457537600,
  "status": "passed"
});
formatter.after({
  "duration": 789063700,
  "status": "passed"
});
formatter.before({
  "duration": 1230877000,
  "status": "passed"
});
formatter.scenario({
  "line": 45,
  "name": "select City",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;select-city",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 46,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 47,
  "name": "user enters city perference as \u0027Mumbai\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 154384400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_city_perference_as_Mumbai()"
});
formatter.result({
  "duration": 532948100,
  "status": "passed"
});
formatter.after({
  "duration": 709135700,
  "status": "passed"
});
formatter.before({
  "duration": 1234808900,
  "status": "passed"
});
formatter.scenario({
  "line": 49,
  "name": "select Mode Of learning",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;select-mode-of-learning",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 50,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 51,
  "name": "user enters mode of learning as \u0027In house training\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 233158000,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_mode_of_learning_as_In_house_training()"
});
formatter.result({
  "duration": 766074000,
  "status": "passed"
});
formatter.after({
  "duration": 771482300,
  "status": "passed"
});
formatter.before({
  "duration": 1232156000,
  "status": "passed"
});
formatter.scenario({
  "line": 53,
  "name": "select Course duration",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;select-course-duration",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 54,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 55,
  "name": "user enters interested course duration as \u00276 months\u0027",
  "keyword": "When "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 804009400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "6",
      "offset": 43
    }
  ],
  "location": "StepDefinitionOnline.user_enters_interested_course_duration_as_months(int)"
});
formatter.result({
  "duration": 1666272500,
  "status": "passed"
});
formatter.after({
  "duration": 712034000,
  "status": "passed"
});
formatter.before({
  "duration": 1270005800,
  "status": "passed"
});
formatter.scenario({
  "line": 57,
  "name": "click on Enquire button with invalid inputs",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;click-on-enquire-button-with-invalid-inputs",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 58,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 59,
  "name": "user enters invalid details",
  "keyword": "When "
});
formatter.step({
  "line": 60,
  "name": "verify the alert box displays \u0027Enquire details must be filled out\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 127547200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enters_invalid_details()"
});
formatter.result({
  "duration": 757911900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_alert_box_displays_Enquire_details_must_be_filled_out()"
});
formatter.result({
  "duration": 1008700100,
  "status": "passed"
});
formatter.after({
  "duration": 717921700,
  "status": "passed"
});
formatter.before({
  "duration": 1334177300,
  "status": "passed"
});
formatter.scenario({
  "line": 62,
  "name": "click on Enquire button with valid inputs",
  "description": "",
  "id": "validting-for-recipe-class-registration--form;click-on-enquire-button-with-valid-inputs",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 63,
  "name": "user is on Recipe_class_registration Form",
  "keyword": "Given "
});
formatter.step({
  "line": 64,
  "name": "user enter valid details",
  "keyword": "When "
});
formatter.step({
  "line": 65,
  "name": "verify the alert box displays \u0027Thank you for submitting the online recipe\u0027",
  "keyword": "Then "
});
formatter.step({
  "line": 66,
  "name": "verify the text \u0027Our location representative will contact you soon\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionOnline.user_is_on_Recipe_class_registration_Form()"
});
formatter.result({
  "duration": 144932100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.user_enter_valid_details()"
});
formatter.result({
  "duration": 1829018900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_alert_box_displays_Thank_you_for_submitting_the_online_recipe()"
});
formatter.result({
  "duration": 1022948600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionOnline.verify_the_text_Our_location_representative_will_contact_you_soon()"
});
formatter.result({
  "duration": 2029939400,
  "status": "passed"
});
formatter.after({
  "duration": 804396600,
  "status": "passed"
});
});