package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryOnline {
	WebDriver driver;
	
	@FindBy(name="fname")
	@CacheLookup
	WebElement fname;
	
	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public WebElement getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public PageFactoryOnline(WebDriver driver) {
		
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}

	@FindBy(id="lname")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="emails")
	@CacheLookup
	WebElement emails;
	
	@FindBy(id="mobile")
	@CacheLookup
	WebElement mobile;
	

	@FindBy(name="D5")
	@CacheLookup
	WebElement city;
	

	@FindBy(name="D6")
	@CacheLookup
	WebElement category;
	

	@FindBy(xpath="/html/body/form/table/tbody/tr[8]/td[2]/select")
	@CacheLookup
	WebElement mode;
	
	
	
	
	@FindBy(xpath="/html/body/form/table/tbody/tr[9]/td[2]/select")
	@CacheLookup
	WebElement duration;
	
	@FindBy(xpath="//a[@href='msg.html']")
	@CacheLookup
	WebElement href;
	
	@FindBy(id="enqdetails")
	@CacheLookup
	WebElement enqdetails;
	
	public WebElement getEnqdetails() {
		return enqdetails;
	}

	public void setEnqdetails(String enqdetails) {
		this.enqdetails.sendKeys(enqdetails);
	}

	public WebElement getHref() {
		return href;
	}

	public void setHref() {
		this.href.click();
	}

	public WebElement getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category.sendKeys(category);
	}

	public WebElement getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode.sendKeys(mode);
	}

	public WebElement getDuration() {
		return duration;
	}

	public void setDuration(String duration) {
		this.duration.sendKeys(duration);
	}

	public WebElement getEmails() {
		return emails;
	}

	public void setEmails(String emails) {
		this.emails.sendKeys(emails);
	}

	public WebElement getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile.sendKeys(mobile);
	}

	@FindBy(id="Submit1")
	@CacheLookup
	WebElement submitButton;

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton( ) {
		this.submitButton.click();
	}
}
