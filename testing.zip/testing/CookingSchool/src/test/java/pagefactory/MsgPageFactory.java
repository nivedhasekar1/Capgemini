package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MsgPageFactory {

	WebDriver driver;
	@FindBy(xpath="//a[@href='Recipe_class_registration.html']")
	@CacheLookup
	WebElement href1;
	public WebDriver getDriver() {
		return driver;
	}
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	
	public WebElement getHref1() {
		return href1;
	}
	public void setHref1() {
		this.href1.click();
	}
	
	
	public MsgPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
}
