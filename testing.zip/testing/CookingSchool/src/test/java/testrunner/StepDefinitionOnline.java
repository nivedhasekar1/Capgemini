package testrunner;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pagefactory.MsgPageFactory;
import pagefactory.PageFactoryOnline;


public class StepDefinitionOnline {
	WebDriver driver;
	PageFactoryOnline pageFactory;
	MsgPageFactory msgFactory;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\nivsekar\\Desktop\\chorme\\chromedriver.exe");

		driver = new ChromeDriver();
	}
	
	@After
	public void quitt() {
		driver.quit();
	}
	@Given("^user is on Recipe_class_registration Form$")
	public void user_is_on_Recipe_class_registration_Form() throws Throwable {
		driver.get("C:\\Users\\nivsekar\\Desktop\\testing\\CookingSchool\\html\\Recipe_class_registration.html");
		pageFactory=new PageFactoryOnline(driver);
	}

	@When("^user enters into html page$")
	public void user_enters_into_html_page() throws Throwable {
		Thread.sleep(1000);//10000
	}

	@Then("^ensure the html pauses for (\\d+)sec$")
	public void ensure_the_html_pauses_for_sec(int arg1) throws Throwable {
		Thread.sleep(1000);//10000
	}

	@Then("^check the title 'Online Cooking Class Enquiry Form'$")
	public void check_the_title_Online_Cooking_Class_Enquiry_Form() throws Throwable {
		String expMsg = "Online Cooking Class Enquiry Form";
		String title=driver.getTitle();
		Assert.assertEquals(expMsg, title);
		
	}

	@Then("^verify the text 'Online Cooking School'$")
	public void verify_the_text_Online_Cooking_School() throws Throwable {
		WebElement text=driver.findElement(By.xpath("//span[@class='auto-style4']"));
		String expMsg="Online Cooking School";
		Assert.assertEquals(expMsg,text);
	}

	@When("^click the hyperlink 'Download our Recipe class Brochure'$")
	public void click_the_hyperlink_Download_our_Recipe_class_Brochure() throws Throwable {
		pageFactory.setHref();
		Thread.sleep(1000);
	}

	@Then("^verify the text 'Recipe class Brochure is sent to your registered mail id'$")
	public void verify_the_text_Recipe_class_Brochure_is_sent_to_your_registered_mail_id() throws Throwable {
		driver.get("C:\\Users\\nivsekar\\Desktop\\testing\\CookingSchool\\html\\msg.html");
		msgFactory=new MsgPageFactory(driver);
		Boolean expMsg=driver.getPageSource().contains("Recipe class Brochure is sent to your registered mail id");
		Boolean text=true;
		Assert.assertEquals(expMsg,text); 
		Thread.sleep(15000);
	}
	@Then("^verify the hyperlink 'Go Back to Registration' is navigated to html page$")
	public void verify_the_hyperlink_Go_Back_to_Registration_is_navigated_to_html_page() throws Throwable {
		msgFactory.setHref1();
		Thread.sleep(1000);
		driver.get("C:\\Users\\nivsekar\\Desktop\\testing\\CookingSchool\\html\\Recipe_class_registration.html");
		Thread.sleep(1000);
	}
	@When("^user enters Enter first name$")
	public void user_enters_Enter_first_name() throws Throwable {
		pageFactory.setFname("");
	    pageFactory.setSubmitButton();
	    Thread.sleep(1000);
	}

	@Then("^display 'First Name must be filled out'$")
	public void display_First_Name_must_be_filled_out() throws Throwable {
		 String expMsg="First Name must be filled out";
		   String actMsg=driver.switchTo().alert().getText();
		   Assert.assertEquals(expMsg, actMsg);
		   driver.switchTo().alert().accept();
		   Thread.sleep(1000);
	}

	@When("^user enters Enter Last name$")
	public void user_enters_Enter_Last_name() throws Throwable {
		 pageFactory.setFname("Nivedha");
		 pageFactory.setLname("");
		    pageFactory.setSubmitButton();
		    Thread.sleep(1000);
	}

	@Then("^display 'Last Name must be filled out'$")
	public void display_Last_Name_must_be_filled_out() throws Throwable {
		String expMsg="Last Name must be filled out";
		   String actMsg=driver.switchTo().alert().getText();
		   Assert.assertEquals(expMsg, actMsg);
		   driver.switchTo().alert().accept();
		   Thread.sleep(1000);
	}

	@When("^user enters Email$")
	public void user_enters_Email() throws Throwable {
		 pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		    pageFactory.setSubmitButton();
		    Thread.sleep(1000);
	}

	@When("^user enters Enter mobile$")
	public void user_enters_Enter_mobile() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("rhhtr");
		 pageFactory.setSubmitButton();
		 Thread.sleep(1000);
	}

	@Then("^display 'Enter numeric value'$")
	public void display_Enter_numeric_value() throws Throwable {
		String expMsg="Enter numeric value";
		   String actMsg=driver.switchTo().alert().getText();
		   Assert.assertEquals(expMsg, actMsg);
		   driver.switchTo().alert().accept();
		   Thread.sleep(1000);
	}
	


	@When("^user enters invalid mobile number less than or greater than (\\d+)$")
	public void user_enters_invalid_mobile_number_less_than_or_greater_than(int arg1) throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("96325");
		  pageFactory.setSubmitButton();
		  Thread.sleep(1000);
	}

	@Then("^display 'Enter (\\d+) digit Mobile Number'$")
	public void display_Enter_digit_Mobile_Number(int arg1) throws Throwable {
		String expMsg="Enter 10 digit Mobile number";
		String actMsg=driver.switchTo().alert().getText();
		Assert.assertEquals(expMsg,actMsg);
		driver.switchTo().alert().accept();
		Thread.sleep(1000);
	}


	@When("^user enters category as 'Non-Veg'$")
	public void user_enters_category_as_Non_Veg() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		  pageFactory.setSubmitButton();
		  Thread.sleep(1000);
	}

	@When("^user enters city perference as 'Mumbai'$")
	public void user_enters_city_perference_as_Mumbai() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		 pageFactory.setCity("Mumbai");
		  pageFactory.setSubmitButton();
	}

	@When("^user enters mode of learning as 'In house training'$")
	public void user_enters_mode_of_learning_as_In_house_training() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		 pageFactory.setCity("Mumbai");
		 pageFactory.setMode("In house training");
		 pageFactory.setSubmitButton();
		  
	}

	@When("^user enters interested course duration as '(\\d+) months'$")
	public void user_enters_interested_course_duration_as_months(int arg1) throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		 pageFactory.setCity("Mumbai");
		 pageFactory.setMode("In house training");
		 pageFactory.setDuration("6 months");
		  pageFactory.setSubmitButton();
		  Thread.sleep(1000);
	}
	
	@When("^user enters invalid details$")
	public void user_enters_invalid_details() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		 pageFactory.setCity("Mumbai");
		 pageFactory.setMode("In house training");
		 pageFactory.setDuration("6 months");
		  pageFactory.setSubmitButton();
	}

	@Then("^verify the alert box displays 'Enquire details must be filled out'$")
	public void verify_the_alert_box_displays_Enquire_details_must_be_filled_out() throws Throwable {
		String expMsg="Enquiry details must be filled out";
		   String actMsg=driver.switchTo().alert().getText();
		   Assert.assertEquals(expMsg, actMsg);
		   driver.switchTo().alert().accept();
		   Thread.sleep(1000);
	}

	@When("^user enter valid details$")
	public void user_enter_valid_details() throws Throwable {
		pageFactory.setFname("Nivedha");
		 pageFactory.setLname("Sekar");
		 pageFactory.setEmails("nivi@gmail.com");
		 pageFactory.setMobile("9632587410");
		 pageFactory.setCategory("Non-Veg");
		 pageFactory.setCity("Mumbai");
		 pageFactory.setMode("In house training");
		 pageFactory.setDuration("6 months");
		 pageFactory.setEnqdetails("In which domain i want to train");
		  pageFactory.setSubmitButton();
		  Thread.sleep(1000);
	}
	@Then("^verify the alert box displays 'Thank you for submitting the online recipe'$")
	public void verify_the_alert_box_displays_Thank_you_for_submitting_the_online_recipe() throws Throwable {
		String expMsg="Thank you for submitting the online recipe class Enquiry";
		   String actMsg=driver.switchTo().alert().getText();
	   Assert.assertEquals(expMsg, actMsg);
	   driver.switchTo().alert().accept();
	   Thread.sleep(1000);
	}
	@Then("^verify the text 'Our location representative will contact you soon'$")
	public void verify_the_text_Our_location_representative_will_contact_you_soon() throws Throwable {
		String expMsg="Our location representative will contact you soon.";
		   String actMsg=driver.findElement(By.tagName("h3")).getText();
	   Assert.assertEquals(expMsg, actMsg);
	   Thread.sleep(2000);
	}





}