package com.cap.google;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nivsekar\\Desktop\\testing\\FirstEx\\src\\test\\resource\\features\\google.feature"},
		glue= {"com.cap.google"},
		dryRun=false,
		strict = true,
		monochrome=true,
		 format = {"pretty" , "html:test-output"}
		)
public class Google_Test_Runner {

}
