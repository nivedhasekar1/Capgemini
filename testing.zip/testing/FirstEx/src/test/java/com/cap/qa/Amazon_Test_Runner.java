package com.cap.qa;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		features= {"C:\\Users\\nivsekar\\Desktop\\testing\\FirstEx\\src\\test\\resource\\features\\amazon.feature"},
		glue= {"com.cap.qa"},
		dryRun=false,
		strict = true,
		monochrome=true,
		 format = {"pretty" , "html:test-output"}
		)


public class Amazon_Test_Runner {

}
