package com.cap.newtours;

public class NewToursPageObject {

}
