package com.cap.google;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class Search_Item_Google_Step_Defination {
	 WebDriver Driver; 
	 String Search_term = "Automation Testing";
	
	
	@Given("^the user is on the google home page$")
	public void the_user_is_on_the_google_home_page() throws Throwable {
	    System.setProperty("webdriver.chrome.driver", "C:\\Users\\nivsekar\\Desktop\\chorme\\chromedriver.exe");
        Driver = new ChromeDriver();
        Driver.get("https://www.google.com"); 
	}

	@Then("^the user should enter Automation Testing in the search textbox$")
	public void the_user_should_enter_Automation_Testing_in_the_search_textbox() throws Throwable {
		   Driver.findElement(By.name("q")).sendKeys(Search_term);
	}

	@Then("^the user should click on Search button$")
	public void the_user_should_click_on_Search_button() throws Throwable {
		Driver.findElement(By.name("q")).submit();
	}

	@Then("^get the title and print$")
	public void get_the_title_and_print() throws Throwable {
		 String title = Driver.getTitle();
		 if(title.contains(Search_term)) {
	            System.out.println("Title is same");
	            
	        }else
	        {
	            System.out.println("Title is not same");
	        }
	}

}
