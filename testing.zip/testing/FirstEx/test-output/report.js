$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nivsekar/Desktop/testing/FirstEx/src/test/resource/features/newtours.feature");
formatter.feature({
  "line": 1,
  "name": "validate the newtour application to book flight ticket",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 8,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight",
  "type": "scenario_outline",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"\u003cDeparture\u003e\" and \"\u003cArrival\u003e\" location",
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.examples({
  "line": 19,
  "name": "",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;",
  "rows": [
    {
      "cells": [
        "Departure",
        "Arrival"
      ],
      "line": 20,
      "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;1"
    },
    {
      "cells": [
        "London",
        "Paris"
      ],
      "line": 21,
      "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;2"
    },
    {
      "cells": [
        "Paris",
        "London"
      ],
      "line": 22,
      "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;3"
    },
    {
      "cells": [
        "New York",
        "Paris"
      ],
      "line": 23,
      "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;4"
    },
    {
      "cells": [
        "London",
        "Zurich"
      ],
      "line": 24,
      "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;5"
    }
  ],
  "keyword": "Examples"
});
formatter.background({
  "line": 3,
  "name": "the user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "click on sign in button",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_login_page()"
});
formatter.result({
  "duration": 127575700,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 19
    },
    {
      "val": "mercury",
      "offset": 33
    }
  ],
  "location": "Search_Item_Step_Defination.the_user_enter_to_and(String,String)"
});
formatter.result({
  "duration": 2452900,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_sign_in_button()"
});
formatter.result({
  "duration": 16700,
  "status": "passed"
});
formatter.scenario({
  "line": 21,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;2",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"London\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_flight_reservation_page()"
});
formatter.result({
  "duration": 20600,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.select_the_passenger_count(DataTable)"
});
formatter.result({
  "duration": 1049300,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "London",
      "offset": 15
    },
    {
      "val": "Paris",
      "offset": 28
    }
  ],
  "location": "Search_Item_Step_Defination.user_to_enter_and_location(String,String)"
});
formatter.result({
  "duration": 65200,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_continue_booking()"
});
formatter.result({
  "duration": 15500,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "the user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "click on sign in button",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_login_page()"
});
formatter.result({
  "duration": 27500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 19
    },
    {
      "val": "mercury",
      "offset": 33
    }
  ],
  "location": "Search_Item_Step_Defination.the_user_enter_to_and(String,String)"
});
formatter.result({
  "duration": 118700,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_sign_in_button()"
});
formatter.result({
  "duration": 15500,
  "status": "passed"
});
formatter.scenario({
  "line": 22,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;3",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"Paris\" and \"London\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_flight_reservation_page()"
});
formatter.result({
  "duration": 27200,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.select_the_passenger_count(DataTable)"
});
formatter.result({
  "duration": 24800,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "Paris",
      "offset": 15
    },
    {
      "val": "London",
      "offset": 27
    }
  ],
  "location": "Search_Item_Step_Defination.user_to_enter_and_location(String,String)"
});
formatter.result({
  "duration": 89300,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_continue_booking()"
});
formatter.result({
  "duration": 15100,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "the user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "click on sign in button",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_login_page()"
});
formatter.result({
  "duration": 29500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 19
    },
    {
      "val": "mercury",
      "offset": 33
    }
  ],
  "location": "Search_Item_Step_Defination.the_user_enter_to_and(String,String)"
});
formatter.result({
  "duration": 71700,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_sign_in_button()"
});
formatter.result({
  "duration": 72600,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;4",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"New York\" and \"Paris\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_flight_reservation_page()"
});
formatter.result({
  "duration": 16800,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.select_the_passenger_count(DataTable)"
});
formatter.result({
  "duration": 29400,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "New York",
      "offset": 15
    },
    {
      "val": "Paris",
      "offset": 30
    }
  ],
  "location": "Search_Item_Step_Defination.user_to_enter_and_location(String,String)"
});
formatter.result({
  "duration": 91400,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_continue_booking()"
});
formatter.result({
  "duration": 14100,
  "status": "passed"
});
formatter.background({
  "line": 3,
  "name": "the user should be logged into the application",
  "description": "",
  "type": "background",
  "keyword": "Background"
});
formatter.step({
  "line": 4,
  "name": "the user is on login page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "the user enter to \"mercury\" and \"mercury\"",
  "keyword": "Then "
});
formatter.step({
  "line": 6,
  "name": "click on sign in button",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_login_page()"
});
formatter.result({
  "duration": 30600,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "mercury",
      "offset": 19
    },
    {
      "val": "mercury",
      "offset": 33
    }
  ],
  "location": "Search_Item_Step_Defination.the_user_enter_to_and(String,String)"
});
formatter.result({
  "duration": 65100,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_sign_in_button()"
});
formatter.result({
  "duration": 23000,
  "status": "passed"
});
formatter.scenario({
  "line": 24,
  "name": "Enter the details in for booking a flight",
  "description": "",
  "id": "validate-the-newtour-application-to-book-flight-ticket;enter-the-details-in-for-booking-a-flight;;5",
  "type": "scenario",
  "keyword": "Scenario Outline"
});
formatter.step({
  "line": 10,
  "name": "the user is on flight reservation page",
  "keyword": "Given "
});
formatter.step({
  "line": 11,
  "name": "select the passenger count",
  "rows": [
    {
      "cells": [
        "1"
      ],
      "line": 12
    },
    {
      "cells": [
        "2"
      ],
      "line": 13
    },
    {
      "cells": [
        "3"
      ],
      "line": 14
    },
    {
      "cells": [
        "4"
      ],
      "line": 15
    }
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 16,
  "name": "user to enter \"London\" and \"Zurich\" location",
  "matchedColumns": [
    0,
    1
  ],
  "keyword": "Then "
});
formatter.step({
  "line": 17,
  "name": "click on continue booking",
  "keyword": "Then "
});
formatter.match({
  "location": "Search_Item_Step_Defination.the_user_is_on_flight_reservation_page()"
});
formatter.result({
  "duration": 21200,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.select_the_passenger_count(DataTable)"
});
formatter.result({
  "duration": 27000,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "London",
      "offset": 15
    },
    {
      "val": "Zurich",
      "offset": 28
    }
  ],
  "location": "Search_Item_Step_Defination.user_to_enter_and_location(String,String)"
});
formatter.result({
  "duration": 64000,
  "status": "passed"
});
formatter.match({
  "location": "Search_Item_Step_Defination.click_on_continue_booking()"
});
formatter.result({
  "duration": 12700,
  "status": "passed"
});
});