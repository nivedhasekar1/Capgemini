package testrunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
       features = {"C:\\Users\\nivsekar\\Desktop\\testing\\Sample\\src\\test\\resource\\Feature\\JobPortal_Features.feature"},
       glue= {"testrunner"},
       dryRun=false,
       strict=true,
       monochrome=false,
       plugin= {"pretty","html:output"}
       )

public class TestRunReg {

}
