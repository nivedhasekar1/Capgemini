package pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class PageFactoryRegister {
	WebDriver driver;
	
	@FindBy(name="userid")
	@CacheLookup
	WebElement userId;
	
	@FindBy(id="pwd")
	@CacheLookup
	WebElement password;
	
	@FindBy(id="usrname")
	@CacheLookup
	WebElement username;
	
	@FindBy(id="addr")
	@CacheLookup
	WebElement address;
	
	public WebElement getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country.sendKeys(country);
	}

	public WebElement getZipcode() {
		return zipcode;
	}

	public void setZipcode(String zipcode) {
		this.zipcode.sendKeys(zipcode);
	}

	public WebElement getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	@FindBy(name="country")
	@CacheLookup
	WebElement country;
	
	@FindBy(name="zip")
	@CacheLookup
	WebElement zipcode;
	
	@FindBy(name="email")
	@CacheLookup
	WebElement email;
	
	
	
	public WebElement getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public WebElement getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	@FindBy(name="submit")
	@CacheLookup
	WebElement submitButton;

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}

	public WebElement getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId.sendKeys(userId);
	}

	public WebElement getSubmitButton() {
		return submitButton;
	}

	public void setSubmitButton() {
		this.submitButton.click();
	}

	public PageFactoryRegister(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver,this);
	}
	
}
