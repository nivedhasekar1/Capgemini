$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nivsekar/Desktop/testing/Sample/src/test/resource/Feature/JobPortal_Features.feature");
formatter.feature({
  "line": 1,
  "name": "Validting for Job Registration Form",
  "description": "",
  "id": "validting-for-job-registration-form",
  "keyword": "Feature"
});
formatter.before({
  "duration": 2102783300,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Checking title",
  "description": "",
  "id": "validting-for-job-registration-form;checking-title",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters the html page",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "displays \u0027Welcome to JobsWorld\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 342480600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_the_html_page()"
});
formatter.result({
  "duration": 1000119300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.displays_Welcome_to_JobsWorld()"
});
formatter.result({
  "duration": 15254700,
  "error_message": "org.junit.ComparisonFailure: expected:\u003c[Welcome to JobsWorld]\u003e but was:\u003c[]\u003e\r\n\tat org.junit.Assert.assertEquals(Assert.java:115)\r\n\tat org.junit.Assert.assertEquals(Assert.java:144)\r\n\tat testrunner.StepDefinitionReg.displays_Welcome_to_JobsWorld(StepDefinitionReg.java:46)\r\n\tat ✽.Then displays \u0027Welcome to JobsWorld\u0027(C:/Users/nivsekar/Desktop/testing/Sample/src/test/resource/Feature/JobPortal_Features.feature:6)\r\n",
  "status": "failed"
});
formatter.after({
  "duration": 811293100,
  "status": "passed"
});
formatter.before({
  "duration": 1211351600,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid UserId",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-userid",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters Invalid id",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "displays \u0027User Id should not be empty / length be between 5 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 244047100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_Invalid_id()"
});
formatter.result({
  "duration": 157282900,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "5",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "StepDefinitionReg.displays_User_Id_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 18674900,
  "status": "passed"
});
formatter.after({
  "duration": 772448800,
  "status": "passed"
});
formatter.before({
  "duration": 1245454500,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Password Field",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-password-field",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user enters invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Password should not be empty / length be between 7 to 12\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 147551100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_password()"
});
formatter.result({
  "duration": 1194677500,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "7",
      "offset": 58
    },
    {
      "val": "12",
      "offset": 63
    }
  ],
  "location": "StepDefinitionReg.display_Password_should_not_be_empty_length_be_between_to(int,int)"
});
formatter.result({
  "duration": 14302700,
  "status": "passed"
});
formatter.after({
  "duration": 725558200,
  "status": "passed"
});
formatter.before({
  "duration": 1320609100,
  "status": "passed"
});
formatter.scenario({
  "line": 18,
  "name": "Invalid Name",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-name",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 19,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 20,
  "name": "user enters invalid name",
  "keyword": "When "
});
formatter.step({
  "line": 21,
  "name": "display \u0027Name should not be empty and must have alphabet characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 165445200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_name()"
});
formatter.result({
  "duration": 1294569100,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.display_Name_should_not_be_empty_and_must_have_alphabet_characters_only()"
});
formatter.result({
  "duration": 14197600,
  "status": "passed"
});
formatter.after({
  "duration": 714580000,
  "status": "passed"
});
formatter.before({
  "duration": 1342719000,
  "status": "passed"
});
formatter.scenario({
  "line": 23,
  "name": "Invalid address",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-address",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 24,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 25,
  "name": "user enters invalid address",
  "keyword": "When "
});
formatter.step({
  "line": 26,
  "name": "display \u0027User address must have alphanumeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 159609600,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_address()"
});
formatter.result({
  "duration": 1420213500,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.display_User_address_must_have_alphanumeric_characters_only()"
});
formatter.result({
  "duration": 27216300,
  "status": "passed"
});
formatter.after({
  "duration": 713952200,
  "status": "passed"
});
formatter.before({
  "duration": 1319119500,
  "status": "passed"
});
formatter.scenario({
  "line": 28,
  "name": "Invalid country",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-country",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 29,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 30,
  "name": "user enters invalid country",
  "keyword": "When "
});
formatter.step({
  "line": 31,
  "name": "display \u0027Select your country from the list\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 184035800,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_country()"
});
formatter.result({
  "duration": 1441979700,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.display_Select_your_country_from_the_list()"
});
formatter.result({
  "duration": 13878200,
  "status": "passed"
});
formatter.after({
  "duration": 713720100,
  "status": "passed"
});
formatter.before({
  "duration": 1281315300,
  "status": "passed"
});
formatter.scenario({
  "line": 33,
  "name": "Invalid ZIP code",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-zip-code",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 34,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 35,
  "name": "user enters invalid ZIP code",
  "keyword": "When "
});
formatter.step({
  "line": 36,
  "name": "display \u0027ZIP code must have numeric characters only\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 171692300,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_ZIP_code()"
});
formatter.result({
  "duration": 1563548200,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.display_ZIP_code_must_have_numeric_characters_only()"
});
formatter.result({
  "duration": 16393600,
  "status": "passed"
});
formatter.after({
  "duration": 716844300,
  "status": "passed"
});
formatter.before({
  "duration": 1268305500,
  "status": "passed"
});
formatter.scenario({
  "line": 38,
  "name": "Invalid email",
  "description": "",
  "id": "validting-for-job-registration-form;invalid-email",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 39,
  "name": "user is on Registartion Form",
  "keyword": "Given "
});
formatter.step({
  "line": 40,
  "name": "user enters invalid email",
  "keyword": "When "
});
formatter.step({
  "line": 41,
  "name": "display \u0027You have entered an invalid email address!\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "StepDefinitionReg.user_is_on_Registartion_Form()"
});
formatter.result({
  "duration": 154304900,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.user_enters_invalid_email()"
});
formatter.result({
  "duration": 1667169400,
  "status": "passed"
});
formatter.match({
  "location": "StepDefinitionReg.display_You_have_entered_an_invalid_email_address()"
});
formatter.result({
  "duration": 14093400,
  "status": "passed"
});
formatter.after({
  "duration": 713002600,
  "status": "passed"
});
});