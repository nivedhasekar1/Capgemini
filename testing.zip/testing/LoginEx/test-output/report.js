$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("C:/Users/nivsekar/Desktop/testing/LoginEx/src/test/resource/feature/login.feature");
formatter.feature({
  "line": 1,
  "name": "hotelBookingLogin",
  "description": "",
  "id": "hotelbookinglogin",
  "keyword": "Feature"
});
formatter.before({
  "duration": 7760607000,
  "status": "passed"
});
formatter.scenario({
  "line": 3,
  "name": "Invalid UserName",
  "description": "",
  "id": "hotelbookinglogin;invalid-username",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 4,
  "name": "User is on \u0027login\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 5,
  "name": "user enters invalid UserName",
  "keyword": "When "
});
formatter.step({
  "line": 6,
  "name": "display \u0027Please Enter UserName\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Step_Defination.user_is_on_login_Page()"
});
formatter.result({
  "duration": 1204315000,
  "status": "passed"
});
formatter.match({
  "location": "Step_Defination.user_enters_invalid_UserName()"
});
formatter.result({
  "duration": 208192800,
  "status": "passed"
});
formatter.match({
  "location": "Step_Defination.display_Please_Enter_UserName()"
});
formatter.result({
  "duration": 353860000,
  "status": "passed"
});
formatter.before({
  "duration": 2076119000,
  "status": "passed"
});
formatter.scenario({
  "line": 8,
  "name": "Invalid Password",
  "description": "",
  "id": "hotelbookinglogin;invalid-password",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 9,
  "name": "User is on \u0027login\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 10,
  "name": "user enters invalid password",
  "keyword": "When "
});
formatter.step({
  "line": 11,
  "name": "display \u0027Please Enter Password\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Step_Defination.user_is_on_login_Page()"
});
formatter.result({
  "duration": 1871121200,
  "status": "passed"
});
formatter.match({
  "location": "Step_Defination.user_enters_invalid_password()"
});
formatter.result({
  "duration": 234574700,
  "status": "passed"
});
formatter.match({
  "location": "Step_Defination.display_Please_Enter_Password()"
});
formatter.result({
  "duration": 612272500,
  "status": "passed"
});
formatter.before({
  "duration": 2177400700,
  "status": "passed"
});
formatter.scenario({
  "line": 13,
  "name": "Invalid Details",
  "description": "",
  "id": "hotelbookinglogin;invalid-details",
  "type": "scenario",
  "keyword": "Scenario"
});
formatter.step({
  "line": 14,
  "name": "User is on \u0027login\u0027 Page",
  "keyword": "Given "
});
formatter.step({
  "line": 15,
  "name": "user enters invalid details",
  "keyword": "When "
});
formatter.step({
  "line": 16,
  "name": "display \u0027Invalid Login Please try again\u0027",
  "keyword": "Then "
});
formatter.match({
  "location": "Step_Defination.user_is_on_login_Page()"
});
formatter.result({
  "duration": 447043200,
  "status": "passed"
});
formatter.match({
  "location": "Step_Defination.user_enters_invalid_details()"
});
