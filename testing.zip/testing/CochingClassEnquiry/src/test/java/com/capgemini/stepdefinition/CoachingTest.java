package com.capgemini.stepdefinition;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
	features = "C:\\Users\\nivsekar\\Desktop\\testing\\CochingClassEnquiry\\feature\\coachingClassEnquiry.feature", 
glue = "com.capgemini.stepdefinition",
dryRun=false,
strict = true,
monochrome=true,
 format = {"pretty" , "html:test-output"}
)
public class CoachingTest {

	public static void main(String[] args) {

	}

}
