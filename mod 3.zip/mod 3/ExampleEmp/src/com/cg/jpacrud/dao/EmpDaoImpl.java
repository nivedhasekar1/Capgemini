package com.cg.jpacrud.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cg.jpacrud.entities.Emp;


public class EmpDaoImpl implements EmpDao{
	
	private EntityManager entityManager;

	public EmpDaoImpl() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public Emp getEmpById(int eid) {
		Emp e = entityManager.find(Emp.class, eid);
		return e;
	}

	@Override
	public void addEmp(Emp e) {
		entityManager.persist(e);
		
	}

	@Override
	public void removeEmp(Emp e) {
		entityManager.remove(e);
		
	}

	@Override
	public void updateEmp(Emp e) {
		entityManager.merge(e);
		
	}

	@Override
	public void commitTransaction() {
		entityManager.getTransaction().commit();
		
	}

	@Override
	public void beginTransaction() {
		entityManager.getTransaction().begin();
		
	}

	@Override
	public List listemp() {
		TypedQuery<Emp> q2=entityManager.createQuery("select c from Emp c",Emp.class);
	    List<Emp> l1=q2.getResultList();
	    for(Emp e4:l1)
	    {
	        System.out.println(e4.geteId());
	        System.out.println(e4.geteName());
	        System.out.println(e4.getAddress());
	        
	    }
		return null;
	}

}
