package com.cg.jpacrud.dao;

import java.util.List;

import com.cg.jpacrud.entities.Emp;

public interface EmpDao {
	public abstract Emp getEmpById(int eid);

	public abstract void addEmp(Emp e);

	public abstract void removeEmp(Emp e);

	public abstract void updateEmp(Emp e);
	
	public  List listemp();

	public abstract void commitTransaction();

	public abstract void beginTransaction();

}
