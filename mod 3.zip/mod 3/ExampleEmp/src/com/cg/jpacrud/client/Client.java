package com.cg.jpacrud.client;

import java.util.List;
import java.util.Scanner;

import com.cg.jpacrud.entities.Emp;
import com.cg.jpacrud.service.EmpService;
import com.cg.jpacrud.service.EmpServiceImpl;
public class Client {
	
	static EmpService service=  new EmpServiceImpl();
	static Emp e=new Emp();
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		while(true){
			System.out.println("1.create employee");
			System.out.println("2.find employee");
			System.out.println("3.update employee");
			System.out.println("4.delete employee");
			System.out.println("5.list employee");
			System.out.println("6.exit");
			System.out.println("Enter your choice:");
			int option=sc.nextInt();
			switch(option){
			
			case 1:
				try{
				System.out.println("Enter emp id:");
				int eid=sc.nextInt();
				System.out.println("Enter emp name:");
				String ename=sc.next();
				System.out.println("Enter emp address:");
				String address=sc.next();
				e.seteId(eid);
				e.seteName(ename);
				e.setAddress(address);
				service.addEmp(e);
				System.out.println(eid);
			}catch(Exception e){
				System.out.println("enter valid no");
			}
				break;
				
			case 2:
				try{
				System.out.println("Enter emp id:");
				int eid1=sc.nextInt();
				e = service.findEmpById(eid1);
				System.out.println("emp name:" +e.geteName());
				System.out.println("emp address:" +e.getAddress());
			}catch(Exception e){
				System.out.println("enter valid no");
			}
				break;
				
			case 3:
				try{
				System.out.println("enter emp id:");
				int eid2=sc.nextInt();
				e=service.findEmpById(eid2);
				System.out.println("update name:");
				String name=sc.next();
				e.seteName(name);
				service.updateEmp(e);
				System.out.println("updated");
				}catch(Exception e){
					System.out.println("enter valid no");
				}
				break;
			
			case 4:
				try{
				System.out.println("enter emp id:");
				int eid3=sc.nextInt();
				e=service.findEmpById(eid3);
                service.removeEmp(e);
				}catch(Exception e){
					System.out.println("enter valid no");
				}
                break;
				
			case 5:
				System.out.println("list employees");
				List<Emp> l1=service.listemp();
			    for(Emp e4:l1)
			    {
			        System.out.println(e4.getAddress());
			       System.out.println(e4.geteId());
			        System.out.println(e4.geteName());
			      
			    }
			   
				break;
				
			case 6:
				System.exit(0);
			}
		}
		
		
	}

}
