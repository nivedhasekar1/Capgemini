package com.cg.jpacrud.service;

import java.util.List;

import com.cg.jpacrud.entities.Emp;

public interface EmpService {
	public abstract void addEmp(Emp e);

	public abstract void updateEmp( Emp e);

	public abstract void removeEmp(Emp e );

	public abstract Emp findEmpById(int eid);
	
	public List listemp();
	
}
