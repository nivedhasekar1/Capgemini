package com.cg.jpacrud.service;


import java.util.List;

import com.cg.jpacrud.dao.EmpDao;
import com.cg.jpacrud.dao.EmpDaoImpl;
import com.cg.jpacrud.entities.Emp;
public class EmpServiceImpl implements EmpService{
	private EmpDao dao;

public EmpServiceImpl() {
		dao = new EmpDaoImpl();
	}

	@Override
	public void addEmp(Emp e) {
		dao.beginTransaction();
		dao.addEmp(e);
		dao.commitTransaction();
		
	}

	@Override
	public void updateEmp(Emp e) {
		dao.beginTransaction();
		dao.updateEmp(e);
		dao.commitTransaction();
		
	}

	@Override
	public void removeEmp(Emp e) {
		dao.beginTransaction();
		dao.removeEmp(e);
		dao.commitTransaction();
		
	}

	@Override
	public Emp findEmpById(int eid) {
		Emp e  = dao.getEmpById(eid);
		return e;
	}

	@Override
	public List listemp() {
		List l2=dao.listemp();
		return l2;
		// List l2=dao.listemp();  
		//return l2;   
	  
		
	}
}

