package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="banktranSpring")
public class BankTransactions {
	 @Id
	    @GeneratedValue
	    @Column(name="transId",length=10)
    private long transId;
	    @Column(name="fromAcc",length=10)
    private long fromAcc;
	    @Column(name="toAcc",length=10)
	    
    private long toAcc;
	    @Column(name="transOldBal",length=10)
    private long transOldBal;
	    @Column(name="transNewBal",length=10)
    private long transNewBal;
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public long getToAcc() {
		return toAcc;
	}
	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}
	public long getTransOldBal() {
		return transOldBal;
	}
	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}
	public long getTransNewBal() {
		return transNewBal;
	}
	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}
	
	@Override
	public String toString() {
		return "BankTransactions [transId=" + transId + ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", transOldBal="
				+ transOldBal + ", transNewBal=" + transNewBal + "]";
	}
    
    
   
//setter and getters
   

}