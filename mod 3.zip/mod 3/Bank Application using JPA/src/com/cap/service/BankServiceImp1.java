package com.cap.service;

import java.util.List;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;
import com.cap.dao.BankDao;
import com.cap.dao.BankDaoImp1;

 

public class BankServiceImp1 implements BankService {
   // BankDetails bean = new BankDetails();
    BankDao dao = new BankDaoImp1();
    @Override
    public long createAccount(BankDetails bankdetails) {
    	dao.beginTransaction();
    	dao.createAccount(bankdetails);
    	dao.commitTransaction();
        return bankdetails.getAccNum();
    }

 

    @Override
    public BankDetails showDetails(long accNum) {
    	//dao.beginTransaction();
    	
    	//dao.commitTransaction();
    	return dao.showDetails(accNum);
    }

 

    @Override
    public long depositDetails(long accNum, long depAcc) {
    	dao.beginTransaction();
        long abc=dao.depositDetails(accNum, depAcc);
        dao.commitTransaction();
        return abc;
    }

 

    @Override
    public long withdrawDetails(long accNum, long withDraw) {
    	dao.beginTransaction();
        long with=dao.withdrawDetails(accNum, withDraw);
        dao.commitTransaction();
        return with;
    }

 

    @Override
    public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
    	dao.beginTransaction();
        long fundTrans1 = dao.fundTransfer(accNum4, accNum5, fundTrans);
         dao.commitTransaction();
        return fundTrans1;
    }

 

    @Override
    public List<BankTransactions> printTransactions() 
    {
        return dao.printTransactions();
    }

 

    //Validation for name
    @Override
    public boolean validateName(String custName)
    {
        if(custName.matches("[A-Z][a-zA-Z]*"))
        {
            return true;
        }
        else
        {
            return false;
        }
    
    }

 

    //Validation for Mobile number
    @Override
    public boolean validateMobNum(long custMobNum) 
    {
        String mobN=Long.toString(custMobNum);
        if(mobN.matches("[6-9][0-9]{9}"))
        {
            return true;
        }
        else
        {
            return false;
        }
            
    }

 

    //Validation to check the type of account
    @Override
    public boolean validateAccType(String accType) 
    {
        
        if(accType.equalsIgnoreCase("savings") || accType.equalsIgnoreCase("current"))
        {
            return false;
        }
        else
        {
            return true;
        }
        
    }
}