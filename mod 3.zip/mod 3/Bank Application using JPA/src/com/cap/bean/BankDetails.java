package com.cap.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="bankEx")
public class BankDetails
{
	
	@Id
	@GeneratedValue
	@Column(length=20)
	private long accNum;
	@Column(length=20)
    private String custName;
	@Column(length=20)
    private long  custMobNum;
	@Column(length=20)
    private String accType;
	@Column(length=20)
    private long accBal;
	@Column(length=20)
    private String custBranch;
    
   
    //setter and getters
    
    public long getAccNum() {
        return accNum;
    }
    public void setAccNum(long accNum) {
        this.accNum = accNum;
    }
    public String getCustName() {
        return custName;
    }
    public void setCustName(String custName) {
        this.custName = custName;
    }
    public long getCustMobNum() {
        return custMobNum;
    }
    public void setCustMobNum(long custMobNum) {
        this.custMobNum = custMobNum;
    }
    public String getAccType() {
        return accType;
    }
    public void setAccType(String accType) {
        this.accType = accType;
    }
    public long getAccBal() {
        return accBal;
    }
    public void setAccBal(long accBal) {
        this.accBal = accBal;
    }
    public String getCustBranch() {
        return custBranch;
    }
    public void setCustBranch(String custBranch) {
        this.custBranch = custBranch;
    }
    @Override
    public String toString() {
        return "BankDetails [custName=" + custName + ", custMobNum=" + custMobNum + ", accType=" + accType + ", accBal="
                + accBal + ", custBranch=" + custBranch + ", accNum=" + accNum + ",]";
    }
    
    
}