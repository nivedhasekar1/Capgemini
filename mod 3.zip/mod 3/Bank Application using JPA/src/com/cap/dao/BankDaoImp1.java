package com.cap.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.TypedQuery;

import com.cap.bean.BankDetails;
import com.cap.bean.BankTransactions;

public class BankDaoImp1 implements BankDao {

	
	public EntityManager entityManager;

	public BankDaoImp1() {
		entityManager = JPAUtil.getEntityManager();
	}

	@Override
	public long createAccount(BankDetails bankdetails) {
		entityManager.persist(bankdetails);
		//System.out.println("hello");
		return bankdetails.getAccNum();
	}

	@Override
	public BankDetails showDetails(long accNum) {
		
		
        BankDetails bankdet=entityManager.find(BankDetails.class, accNum);
        
        return bankdet;
	}

	@Override
	public long depositDetails(long accNum, long depAcc) {
		BankDetails acc=entityManager.find(BankDetails.class, accNum);
        long oldBal=acc.getAccBal();
        long newBal=oldBal+depAcc;
        acc.setAccBal(newBal);
        entityManager.merge(acc);
        
        BankTransactions transaction =new  BankTransactions();
           // transaction.setAccNum(accNum);
            transaction.setFromAcc(accNum);
            transaction.setToAcc(accNum);
            transaction.setTransOldBal(oldBal);
            transaction.setTransNewBal(newBal);
            transaction.setTransType("Debit");
            entityManager.persist(transaction);
        
        return newBal;
	}

	@Override
	public long withdrawDetails(long accNum, long withDraw) {
		BankDetails acc=entityManager.find(BankDetails.class, accNum);
        long oldBal=acc.getAccBal();
        long newBal=oldBal-withDraw;
        acc.setAccBal(newBal);
        entityManager.merge(acc);
        
        BankTransactions transaction =new  BankTransactions();
       // transaction.setAccNum(accNum);
        transaction.setFromAcc(accNum);
        transaction.setToAcc(accNum);
        transaction.setTransOldBal(oldBal);
        transaction.setTransNewBal(newBal);
        transaction.setTransType("WithDraw");
        entityManager.persist(transaction);
        
        return newBal;
	}

	@Override
	public long fundTransfer(long accNum4, long accNum5, long fundTrans) {
		BankDetails acc=entityManager.find(BankDetails.class, accNum4);
        long oldBal=acc.getAccBal();
        long newBal=oldBal+fundTrans;
        acc.setAccBal(newBal);
        entityManager.merge(acc);
        BankTransactions transaction =new  BankTransactions();
           // transaction.setAccNum(accNum);
            transaction.setFromAcc(accNum4);
            transaction.setToAcc(accNum5);
            transaction.setTransOldBal(oldBal);
            transaction.setTransNewBal(newBal);
            transaction.setTransType("FundTrans");
            entityManager.persist(transaction);
        
        BankDetails acc1=entityManager.find(BankDetails.class, accNum5);
        long oldBal1=acc1.getAccBal();
        long newBal1=oldBal1-fundTrans;
        acc.setAccBal(newBal1);
        entityManager.merge(acc1);
        
        BankTransactions transactions =new  BankTransactions();
           // transaction.setAccNum(accNum);
            transactions.setFromAcc(accNum4);
            transactions.setToAcc(accNum5);
            transactions.setTransOldBal(oldBal1);
            transactions.setTransNewBal(newBal1);
            transactions.setTransType("FundTrans");
            entityManager.persist(transaction);
        return newBal;
	}
    //BankService serviceObj=new BankServiceImp1();

	@Override
	public void beginTransaction() {
		
		entityManager.getTransaction().begin();
	}

	@Override
	public void commitTransaction() {
		
		entityManager.getTransaction().commit();
	}
    
	@Override
    public List<BankTransactions> printTransactions()
   {
       
       TypedQuery<BankTransactions> q2=entityManager.createQuery("select b from BankTransactions b",BankTransactions.class);
       List<BankTransactions> value=q2.getResultList();
       return value;
   }
}
    
