package com.cap.exception;

public class NameValidateError extends RuntimeException{
	public NameValidateError(final String message)
	{
		super(message);
	}
}
