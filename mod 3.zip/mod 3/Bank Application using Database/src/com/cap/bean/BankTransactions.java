package com.cap.bean;

public class BankTransactions {
    private long transId;
    private String transType;
    private long transOldBal;
    private long fromAcc;
    private long toAcc;
    private long transNewBal;
//setter and getters
	public long getTransId() {
		return transId;
	}
	public void setTransId(long transId) {
		this.transId = transId;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public long getTransOldBal() {
		return transOldBal;
	}
	public void setTransOldBal(long transOldBal) {
		this.transOldBal = transOldBal;
	}
	public long getFromAcc() {
		return fromAcc;
	}
	public void setFromAcc(long fromAcc) {
		this.fromAcc = fromAcc;
	}
	public long getToAcc() {
		return toAcc;
	}
	public void setToAcc(long toAcc) {
		this.toAcc = toAcc;
	}
	public long getTransNewBal() {
		return transNewBal;
	}
	public void setTransNewBal(long transNewBal) {
		this.transNewBal = transNewBal;
	}
	@Override
	public String toString() {
		return "BankTransactions [transId=" + transId + ", transType=" + transType + ", transOldBal=" + transOldBal
				+ ", fromAcc=" + fromAcc + ", toAcc=" + toAcc + ", transNewBal=" + transNewBal + "]";
	}
    
 

}