package com.cap.exception;

public class NameValidateError extends RuntimeException{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public NameValidateError(final String message)
	{
		super(message);
	}
}
